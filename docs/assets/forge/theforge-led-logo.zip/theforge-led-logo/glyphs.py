"""Pixel-art glyphs for The Forge LED logo (64x32 panel).

Every sprite is a list of equal-length strings. Character -> palette slot:
    '.'  transparent   (slot 0)
    '#'  brand yellow  (slot 1)
    'o'  hot orange    (slot 2)  - ember cores, spark fringes
    'w'  spark white   (slot 3)  - white-hot highlights
    's'  steel         (slot 9)  - tool bodies (never recolored by effects)
    'd'  dark iron     (slot 10) - tool outlines and shadows
    'b'  wood tan      (slot 11) - boards, handles

The wordmark is FORGE in a heavy condensed grotesque, matching the brand's
black-caps-in-a-yellow-block mark. Three sizes: CAPS20 (10x20, 3px stroke,
the hero), CAPS13 (8x13, 2px, emblem + knockout block), CAPS8 (5x8, THE
and the badge stack). The O carries a small ember core in its counter —
the pilot light, this mark's equivalent of the DarkOwl eyes.

Logo glyphs use ONLY slots 1-3: every downstream system (the swarm's
color map, the ember-gradient tile, the palette partitions) assumes logo
pixels live there. Steel/wood slots are for the vignette actors.
"""

import sys

# All colors in this file are DESIGN values: what the mark should look like
# on an sRGB monitor (the simulator shows them verbatim). The HUB75 panel's
# BCM drive is LINEAR in the channel value, so fed the same numbers it emits
# ~10x too much light in the dark channels. On hardware, panel_color()
# gamma-encodes every design color once at import; on desktop it is the
# identity, so previews keep the design intent.
PANEL_GAMMA = 2.2
_ON_PANEL = sys.implementation.name == "circuitpython"
try:
    import os
    # Desktop opt-in, for inspecting the hardware mapping without a board.
    _ON_PANEL = _ON_PANEL or bool(os.getenv("FORGE_PANEL_GAMMA"))
except ImportError:
    pass


def panel_color(color):
    """Design (sRGB) color -> panel drive color. Identity on desktop."""
    if not _ON_PANEL:
        return color
    out = 0
    for shift in (16, 8, 0):
        v = (color >> shift) & 0xFF
        out |= int((v / 255.0) ** PANEL_GAMMA * 255.0 + 0.5) << shift
    return out


# The brand yellow, sampled from the logo asset (#F7EE21) — already bright
# enough for LEDs as-is.
YELLOW = panel_color(0xF7EE21)
HOT = panel_color(0xE86010)          # ember cores, spark fringes
SPARK_WHITE = panel_color(0xFFF6D8)  # white-hot highlights

# Material shades for the vignette actors (dedicated slots so no effect
# animation can ever recolor them): steel bodies, dark iron outlines,
# wood for boards and handles.
STEEL = panel_color(0x9AA4AC)
DARK_IRON = panel_color(0x3A4048)
WOOD = panel_color(0xC98A3C)

CHAR_TO_SLOT = {".": 0, "#": 1, "o": 2, "w": 3, "s": 9, "d": 10, "b": 11}
PALETTE_COLORS = (0x000000, YELLOW, HOT, SPARK_WHITE)  # slot 0 transparent
MATERIAL_SHADES = (STEEL, DARK_IRON, WOOD)             # slots 9-11

# The heat gradation: a five-stop black-body ramp, dull ember red through
# white-hot, for the ignition/heat variations. Cooling metal passes THROUGH
# brand yellow on its way down, so every heat beat can settle onto the flat
# mark. Stops chosen so that after the panel gamma they still land on
# distinct quantized RGB666 levels (red-channel drives: 10/25/47/59/63 of
# 63; green walks 0/1/7/37/59 — the red-orange-yellow-white hue walk
# survives the panel).
HEAT_RAMP = tuple(panel_color(c)
                  for c in (0x6E1408, 0xA83208, 0xE06010, 0xF7C81E, 0xFFF6C8))

# Temper Library: curated brand-adjacent editions of the mark, each a
# subtle two-stop gradient (lo, hi). The names are literal — these are the
# straw/gold/bronze band of real steel temper colors (the purple/blue end
# is excluded: it loses the yellow heart).
TEMPER_EDITIONS = tuple(
    (panel_color(lo), panel_color(hi)) for lo, hi in (
        (0xC8B818, 0xF7EE21),    # safety (the flat brand, home state)
        (0xB89020, 0xE8C838),    # straw
        (0xD84E10, 0xF7A018),    # molten
        (0x8A6A18, 0xC8A030),    # brass
        (0xE8D060, 0xFFF6C8),    # white heat
        (0x7A3608, 0xB86010),    # banked coals (darkest allowed)
    ))

# ---------------------------------------------------------------------------
# CAPS20 — the hero letters: 10x20, 3px stroke, heavy condensed.
# FORGE = 5 x 10px + 4 x 2px gaps = 58px wide.
# ---------------------------------------------------------------------------
CAPS20 = {
    "F": [
        "##########",
        "##########",
        "##########",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "#########.",
        "#########.",
        "#########.",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
    ],
    "O": [
        ".########.",
        "##########",
        "##########",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "##########",
        "##########",
        ".########.",
    ],
    "R": [
        "#########.",
        "##########",
        "##########",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "##########",
        "##########",
        "#########.",
        "###.###...",
        "###.###...",
        "###..###..",
        "###..###..",
        "###..###..",
        "###...###.",
        "###...###.",
        "###...###.",
        "###....###",
        "###....###",
    ],
    "G": [
        ".########.",
        "##########",
        "##########",
        "###....###",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###..#####",
        "###..#####",
        "###..#####",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "###....###",
        "##########",
        "##########",
        ".########.",
    ],
    "E": [
        "##########",
        "##########",
        "##########",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "#########.",
        "#########.",
        "#########.",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "###.......",
        "##########",
        "##########",
        "##########",
    ],
}

# ---------------------------------------------------------------------------
# CAPS13 — 8x13, 2px stroke: the emblem wordmark and the knockout block.
# FORGE = 5 x 8px + 4 x 1px gaps = 44px wide.
# ---------------------------------------------------------------------------
CAPS13 = {
    "F": [
        "########",
        "########",
        "##......",
        "##......",
        "##......",
        "#######.",
        "#######.",
        "##......",
        "##......",
        "##......",
        "##......",
        "##......",
        "##......",
    ],
    "O": [
        ".######.",
        "########",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "##....##",
        "########",
        ".######.",
    ],
    "R": [
        "#######.",
        "########",
        "##....##",
        "##....##",
        "########",
        "#######.",
        "##.##...",
        "##.##...",
        "##..##..",
        "##..##..",
        "##...##.",
        "##...##.",
        "##....##",
    ],
    "G": [
        ".######.",
        "########",
        "##....##",
        "##......",
        "##......",
        "##......",
        "##..####",
        "##..####",
        "##....##",
        "##....##",
        "##....##",
        "########",
        ".######.",
    ],
    "E": [
        "########",
        "########",
        "##......",
        "##......",
        "##......",
        "#######.",
        "#######.",
        "##......",
        "##......",
        "##......",
        "##......",
        "########",
        "########",
    ],
}

# ---------------------------------------------------------------------------
# CAPS8 — 5x8: THE for the rows layout, and the badge's stacked words.
# THE = 17px; FORGE = 29px.
# ---------------------------------------------------------------------------
CAPS8 = {
    "T": [
        "#####",
        "#####",
        "..#..",
        "..#..",
        "..#..",
        "..#..",
        "..#..",
        "..#..",
    ],
    "H": [
        "##.##",
        "##.##",
        "##.##",
        "#####",
        "#####",
        "##.##",
        "##.##",
        "##.##",
    ],
    "E": [
        "#####",
        "#####",
        "##...",
        "####.",
        "####.",
        "##...",
        "#####",
        "#####",
    ],
    "F": [
        "#####",
        "#####",
        "##...",
        "####.",
        "####.",
        "##...",
        "##...",
        "##...",
    ],
    "O": [
        ".###.",
        "#####",
        "##.##",
        "##.##",
        "##.##",
        "##.##",
        "#####",
        ".###.",
    ],
    "R": [
        "####.",
        "#####",
        "##.##",
        "####.",
        "####.",
        "##.##",
        "##.##",
        "##.##",
    ],
    "G": [
        ".####",
        "#####",
        "##...",
        "##...",
        "##.##",
        "##.##",
        "#####",
        ".####",
    ],
}


def _with_core(rows, core_rows, x0, y0):
    """A copy of a glyph with an ember core stamped into its counter."""
    out = list(rows)
    for dy, crow in enumerate(core_rows):
        row = out[y0 + dy]
        out[y0 + dy] = row[:x0] + crow + row[x0 + len(crow):]
    return out


# The pilot light: a 2x3 ember cluster (hot orange with a white-hot cap)
# in the O's counter. It breathes during dwells and flares on the mark's
# micro-events — the fire inside, at word scale.
O_CORE20 = _with_core(CAPS20["O"], ("ow", "oo", "oo"), 4, 8)
O_CORE13 = _with_core(CAPS13["O"], ("ow", "oo", "oo"), 3, 5)


def scale2(rows):
    """Integer 2x scale of a glyph: every pixel becomes 2x2, so 1px
    strokes stay uniform at 2px instead of aliasing."""
    out = []
    for row in rows:
        wide = "".join(ch + ch for ch in row)
        out.append(wide)
        out.append(wide)
    return out


def knockout_rows(word, letters, pad_x, pad_y, gap, core=None):
    """The brand-literal block: a solid yellow rectangle with the word's
    letterforms punched out as unlit pixels (their counters stay yellow).
    ``core`` optionally names a letter whose ember-core variant is used,
    so the pilot light burns in the knockout too."""
    widths = [len(letters[ch][0]) for ch in word]
    height = len(letters[word[0]])
    w = sum(widths) + gap * (len(word) - 1) + 2 * pad_x
    rows = [["#"] * w for _ in range(height + 2 * pad_y)]
    x = pad_x
    for ch, lw in zip(word, widths):
        src = core if ch == "O" and core else letters[ch]
        for gy, row in enumerate(src):
            for gx, c in enumerate(row):
                if c == "#":
                    rows[pad_y + gy][x + gx] = "."
                elif c in "ow":
                    rows[pad_y + gy][x + gx] = c
        x += lw + gap
    return ["".join(r) for r in rows]


# ---------------------------------------------------------------------------
# The anvil — the signature prop. London pattern: horn tapering left, flat
# working face, waist, spreading base. Two renderings of one silhouette:
# the STEEL anvil for the strike vignette, and a brand-yellow stencil
# version that joins the emblem/badge layouts as a logo element (layout
# glyphs must live in slots 1-3; see module docstring). The stencil's face
# carries a small ember hot-spot — the anchor the wake/halo effects
# radiate from.
# ---------------------------------------------------------------------------
ANVIL = [
    ".....wwwwwsssssssssss",
    "..sssssssssssssssssss",
    "sssssssssssssssssssss",
    ".......dssssssssssd..",
    "........dssssssssd...",
    ".........ssssssss....",
    ".........ssssssss....",
    "........dssssssssd...",
    ".......dssssssssssd..",
    ".....ddssssssssssssd.",
    "....sssssssssssssssss",
    "...ddddddddddddddddd.",
]


def _stencil(rows, face_x=None):
    """The one-color logo rendering of a steel sprite: every lit pixel
    goes brand yellow, with an ember hot-spot on the working face at
    ``face_x`` (the anchor the wake/halo effects radiate from)."""
    out = []
    for row in rows:
        out.append("".join("#" if c != "." else "." for c in row))
    if face_x is not None:
        out[0] = out[0][:face_x] + "ow" + out[0][face_x + 2:]
        out[1] = out[1][:face_x] + "oo" + out[1][face_x + 2:]
    return out


ANVIL_LOGO = _stencil(ANVIL, face_x=9)

# The badge layout's hero anvil (28x18), same silhouette drawn larger.
ANVIL_XL = [
    ".......wwwwwwssssssssssssss.",
    "....ssssssssssssssssssssssss",
    ".sssssssssssssssssssssssssss",
    "ssssssssssssssssssssssssssss",
    "..........dsssssssssssssd...",
    "...........dsssssssssssd....",
    "............sssssssssss.....",
    "............sssssssssss.....",
    "............sssssssssss.....",
    "............sssssssssss.....",
    "...........dsssssssssssd....",
    "..........dsssssssssssssd...",
    ".........dsssssssssssssssd..",
    "........dsssssssssssssssssd.",
    "......ssssssssssssssssssssss",
    ".....sssssssssssssssssssssss",
    "....dddddddddddddddddddddddd",
    "....dddddddddddddddddddddddd",
]
ANVIL_XL_LOGO = _stencil(ANVIL_XL, face_x=13)

# ---------------------------------------------------------------------------
# The hammer: three rotation poses around a pivot at the handle's end
# (lower right), cycled UP -> MID -> DOWN for the strike arc. Cross-peen
# head in steel with a dark cheek, wood handle. In the DOWN pose the
# striking face is the sprite's lower-left corner — position that on the
# anvil's face.
# ---------------------------------------------------------------------------
HAMMER_UP = [
    "....ssss......",
    "...ssssss.....",
    "...sddsss.....",
    "...ssssss.....",
    "....ssbb......",
    "......bb......",
    ".......bb.....",
    ".......bb.....",
    "........bb....",
    "........bb....",
    ".........bb...",
    ".........bb...",
]
HAMMER_MID = [
    "..............",
    ".ssss.........",
    "ssssss........",
    "sddsss........",
    "ssssss........",
    ".....sbb......",
    ".......bb.....",
    "........bb....",
    ".........bb...",
    "..........bb..",
    "...........bb.",
    "..............",
]
HAMMER_DOWN = [
    "..............",
    "............bb",
    "...........bb.",
    "..........bb..",
    ".........bb...",
    "........bb....",
    ".sssssssbb....",
    "ssssssss......",
    "sdddssss......",
    "ssssssss......",
    "wsssssss......",
    "..............",
]

# The impact flash: three expansion frames of a spark burst, white core
# with orange fringe. Played at the hammer's contact point, then the
# ballistic spark pool takes over.
SPARK_BURST_A = [
    "..........",
    "....ww....",
    "...wwww...",
    "....ww....",
    "..........",
    "..........",
]
SPARK_BURST_B = [
    "....oo....",
    "..owwwwo..",
    ".owwwwwwo.",
    "..owwwwo..",
    "....oo....",
    "..........",
]
SPARK_BURST_C = [
    ".o..oo..o.",
    "o.ow..wo.o",
    ".o......o.",
    "o.o....o.o",
    ".o..o..o..",
    "..........",
]

# ---------------------------------------------------------------------------
# The laser cutter's head: a small carriage hanging from the gantry rail,
# lens at the bottom — the beam tile hangs from (3, 4).
# ---------------------------------------------------------------------------
LASER_HEAD = [
    ".ddddd.",
    ".sssss.",
    ".sssss.",
    "..sws..",
    "...w...",
]


def _saw(phase):
    """A 13px circular saw blade. The rim's teeth alternate steel/dark by
    parity; the two phases offset by one so a 2-frame pose swap spins it."""
    rows = []
    for y in range(13):
        row = []
        for x in range(13):
            dx, dy = x - 6, y - 6
            d2 = dx * dx + dy * dy
            if d2 > 40:
                row.append(".")
            elif d2 >= 27:
                row.append("s" if (x + y + phase) % 2 else "d")
            elif d2 <= 2:
                row.append("d")
            else:
                row.append("s")
        rows.append("".join(row))
    return rows


SAW_A = _saw(0)
SAW_B = _saw(1)

# The board the saw rips: two abutting halves (they read as one plank
# until the cut opens), tan with warm grain streaks.
BOARD_L = [
    "bbbbbbbbbbbbbbbbbbbbbbbb",
    "bbbobbbbbbbbbbobbbbbbbbb",
    "bbbbbbbbbbbbbbbbbbbbbbbb",
    "bbbbbbbobbbbbbbbbbbobbbb",
    "bbbbbbbbbbbbbbbbbbbbbbbb",
    "bobbbbbbbbbbbobbbbbbbbbb",
]
BOARD_R = [
    "bbbbbbbbbbbbbbbbbbbbbb",
    "bbbbbbbobbbbbbbbbobbbb",
    "bbbbbbbbbbbbbbbbbbbbbb",
    "bbobbbbbbbbbobbbbbbbbb",
    "bbbbbbbbbbbbbbbbbbbbbb",
    "bbbbbbbbbobbbbbbbbbobb",
]

# The MIG torch: cable and grip up-right, nozzle at the lower-left tip.
# The blue-white arc itself is a separate tiny tile with its own palette
# (the one cool accent in the show, diegetic and localized).
TORCH = [
    "......ss",
    ".....sss",
    "....ss..",
    "..dss...",
    ".dds....",
    "d.......",
]

# The potter's wheel: an 18px disk edge-on (two dash phases spin it) on a
# short dark shaft, and four clay profiles — lump, cylinder, waisted
# vase, finished pot. The pot's kiln-hot rendering swaps tan for orange.
WHEEL_A = [
    "sdsdsdsdsdsdsdsdsd",
    "dsdsdsdsdsdsdsdsds",
    "........dd........",
    "........dd........",
]
WHEEL_B = [
    "dsdsdsdsdsdsdsdsds",
    "sdsdsdsdsdsdsdsdsd",
    "........dd........",
    "........dd........",
]
CLAY_1 = [
    "....bbbb....",
    "..bbbbbbbb..",
    ".bbbbbbbbbb.",
    "bbbbbbbbbbbb",
]
CLAY_2 = [
    "...bbbbbb...",
    "...bbbbbb...",
    "...bbbbbb...",
    "...bbbbbb...",
    "...bbbbbb...",
    "...bbbbbb...",
]
CLAY_3 = [
    "..bbbbbbbb..",
    ".bbbbbbbbbb.",
    ".bbbbbbbbbb.",
    "..bbbbbbbb..",
    "...bbbbbb...",
    "...bbbbbb...",
    "..bbbbbbbb..",
]
CLAY_4 = [
    ".bbbbbbbbbb.",
    ".bbbbbbbbbb.",
    "..bbbbbbbb..",
    "..bbbbbbbb..",
    "...bbbbbb...",
    "...bbbbbb...",
    "..bbbbbbbb..",
]
POT_HOT = ["".join("o" if c == "b" else c for c in row) for row in CLAY_4]

# The sewing machine, arm-and-bed silhouette facing left: head with the
# needle bar at the left, pillar at the right, flat bed. Two needle
# poses (up / down to the bed) make the stitch cycle.
SEWER_A = [
    "..ssssssssssss..",
    ".ssssssssssssss.",
    ".sss........ss..",
    ".sss........ss..",
    ".sds........ss..",
    "..d.........ss..",
    "............ss..",
    "............ss..",
    "................",
    "ssssssssssssssss",
    "ssssssssssssssss",
    "...dd......dd...",
]
SEWER_B = [
    "..ssssssssssss..",
    ".ssssssssssssss.",
    ".sss........ss..",
    ".sss........ss..",
    ".sds........ss..",
    "..d.........ss..",
    "..d.........ss..",
    "..d.........ss..",
    "................",
    "ssssssssssssssss",
    "ssssssssssssssss",
    "...dd......dd...",
]
