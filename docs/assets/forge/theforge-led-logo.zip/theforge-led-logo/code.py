# The Forge LED logo — device entry point (Adafruit MatrixPortal S3).
# Runs the 24/7 shuffle: every build, dwell treatment, and exit across
# all five layouts, scheduled so nothing similar ever plays twice.
import asyncio

from forge_logo import ForgeLogoApp

asyncio.run(ForgeLogoApp("shuffle").run())
