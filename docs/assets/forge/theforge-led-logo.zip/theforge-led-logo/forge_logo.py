#!/usr/bin/env python3
"""The Forge logo animations for a 64x32 LED matrix (ScrollKit).

The FORGE wordmark — heavy condensed caps in the brand's safety yellow —
rendered as pixel art across five layouts, plus maker vignettes for the
shops. Versions, picked on the command line:

    python3 forge_logo.py static      # the mark, held (pilot-light flare)
    python3 forge_logo.py line        # layout: FORGE at full size
    python3 forge_logo.py block       # layout: the brand knockout block
    python3 forge_logo.py rows        # layout: THE over FORGE
    python3 forge_logo.py emblem      # layout: the anvil above the word
    python3 forge_logo.py badge       # layout: big anvil, words stacked
    python3 forge_logo.py heat        # the mark glows up through the
                                      # black-body ramp, breathes, dies down
    python3 forge_logo.py temper      # the steel temper color editions
    python3 forge_logo.py anneal      # a hot sheen sweeps the mark
    python3 forge_logo.py strikewake  # heat rings out from the pilot light
    python3 forge_logo.py heatbloom   # radial heat waves from the anchor
    python3 forge_logo.py beacon      # a hot wedge sweeps around the mark
    python3 forge_logo.py sparkrain   # falling ember phases in the strokes
    python3 forge_logo.py shimmer     # heat haze over the letterforms
    python3 forge_logo.py caseharden  # edges cool dark while cores glow
    python3 forge_logo.py hotspots    # regions warm and cool unevenly
    python3 forge_logo.py toolpath    # hot packets crawl the strokes
    python3 forge_logo.py jobqueue    # packet dots walk the letter paths
    python3 forge_logo.py worklight   # a shop light rakes the strokes
    python3 forge_logo.py swarm       # a spark flock assembles the mark
    python3 forge_logo.py drip        # the mark rains in from the sky
    python3 forge_logo.py wink        # a wall of yellow winks down to it
    python3 forge_logo.py strike      # hammer + anvil forge the wordmark
    python3 forge_logo.py laser       # the laser cuts it from steel plate
    python3 forge_logo.py sawmill     # the table saw rips a board
    python3 forge_logo.py sawcut      # ...or cuts the sign in half (exit)
    python3 forge_logo.py print       # the 3D printer rasters it in
    python3 forge_logo.py weld        # the MIG torch welds the block shut
    python3 forge_logo.py wheel       # the potter's wheel throws a pot
    python3 forge_logo.py stitch      # the sewing machine underlines it
    python3 forge_logo.py quench      # heat up, drop in the slack tub
    python3 forge_logo.py unforge     # the hammer takes it all back
    python3 forge_logo.py molten      # molten glow through the strokes
    python3 forge_logo.py tour        # several treatments back to back
    python3 forge_logo.py shuffle     # endless scheduled acts (24/7 mode)

Runs in the ScrollKit desktop simulator (pygame window). The same code
runs on an Adafruit MatrixPortal S3.
"""

import sys

if sys.implementation.name != "circuitpython":
    # Desktop only: fall back to the ScrollKit checkout (not pip-installed)
    # and make this file's directory importable. On the device, scrollkit
    # lives in /lib and the app modules sit at the drive root, so the
    # default sys.path already covers both (and os.path doesn't exist).
    import os

    _SCROLLKIT_SRC = ("/Users/czei/Documents/Projects/ScrollKit/"
                      "ScrollKit Library/src")
    try:
        import scrollkit  # noqa: F401
    except ImportError:
        sys.path.insert(0, _SCROLLKIT_SRC)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import asyncio
import math
import random

from scrollkit.app.base import ScrollKitApp
from scrollkit.display.unified import displayio
from scrollkit.effects.drip_splash import DripReveal
from scrollkit.effects.reveal_splash import show_reveal_splash
from scrollkit.effects.swarm_reveal import SwarmReveal
from scrollkit.effects.transitions import _TRANSITION_MAP

from glyphs import (
    ANVIL,
    ANVIL_LOGO,
    ANVIL_XL_LOGO,
    BOARD_L,
    BOARD_R,
    CAPS8,
    CAPS13,
    CAPS20,
    CHAR_TO_SLOT,
    CLAY_1,
    CLAY_2,
    CLAY_3,
    CLAY_4,
    HAMMER_DOWN,
    HAMMER_MID,
    HAMMER_UP,
    HEAT_RAMP,
    LASER_HEAD,
    MATERIAL_SHADES,
    O_CORE13,
    O_CORE20,
    PALETTE_COLORS,
    POT_HOT,
    SAW_A,
    SAW_B,
    SEWER_A,
    SEWER_B,
    SPARK_BURST_A,
    SPARK_BURST_B,
    SPARK_BURST_C,
    TEMPER_EDITIONS,
    TORCH,
    WHEEL_A,
    WHEEL_B,
    knockout_rows,
    panel_color,
)

from scrollkit.effects.palette_partition import (
    PalettePartition,
    bfs_paths,
    map_anchor_distance,
    map_angle,
    map_checker,
    map_diagonal,
    map_exposure,
    map_radial,
    map_rain,
    map_regions,
    map_route,
    map_topology,
)
from scrollkit.effects.palette_treatments import (
    AnchorWake,
    CipherRain,
    GradientDwell,
    HaloPulse,
    HeatmapDrift,
    InkShimmer,
    PacketTrace,
    RimLight,
    RouteCircuit,
    SonarSweep,
    StrokeAnatomy,
    VelvetSweep,
)
from scrollkit.utils.scheduler import ActScheduler

# One shared palette: flat colors, then the heat ramp, then tool materials.
ALL_COLORS = PALETTE_COLORS + HEAT_RAMP + MATERIAL_SHADES

# Shorthand for the effect treatments (all brand-adjacent heat tones).
H_EMBER, H_RED, H_ORANGE, H_YELLOW, H_WHITE = HEAT_RAMP

# Panel-corrected accents. These override scrollkit treatment DEFAULTS,
# which are design-space values and would render too bright on the linear
# panel (glyphs.panel_color has the whole story).
CIRCUIT_BASE = panel_color(0x4A3C06)     # toolpath/jobqueue dim base
WORKLIGHT_SHADE = panel_color(0x5A4A08)  # rimlight's sheltered side

SPARK_COLOR = panel_color(0xFFE84A)      # the swarm flock, hot pale yellow
SPARK_MID = panel_color(0xFFC838)        # a pool spark's mid-life color
NUM_BIRDS = 16                           # device-safe (<= ~20 on an S3)

# Vignette-only accents, each on its own tiny palette so the shared logo
# palette never learns a cool color. The laser is red — it reads "laser",
# and it keeps the whole show on the warm axis; the welding arc is the
# one blue-white exception, diegetic and localized.
LASER_RED = panel_color(0xFF2010)
LASER_DIM = panel_color(0xB01008)
SHEET_GRAY = panel_color(0x6A727A)       # uncut steel plate
ARC_BRIGHT = panel_color(0xCEE6FF)
ARC_HALO = panel_color(0x86B4FF)
SAWDUST = panel_color(0xE8C888)
STEAM = panel_color(0xC8D8E0)

# Acts choreographed around specific compositions. An act listed here only
# plays on the named layouts; everything else works on any layout's pixels.
# (toolpath/jobqueue need per-letter routes, which the one-glyph block
# doesn't have. The tool vignettes set their own layouts internally.)
ACT_LAYOUTS = {
    "toolpath": ("line", "rows", "emblem", "badge"),
    "jobqueue": ("line", "rows", "emblem", "badge"),
}

# Library transitions used to build / unbuild the logo (aesthetic split —
# every transition can do both). Names are scrollkit's _TRANSITION_MAP keys.
BUILD_TRANSITIONS = ("Light Slit", "Iris Snap", "Mosaic Resolve",
                     "Gradual Reveal", "Venetian Shutters", "Scan Fold")
HIDE_TRANSITIONS = ("CRT Collapse", "Pixel Dissolve", "Glitch Bars",
                    "Column Rain", "Diagonal Wipe", "Horizontal Wipe")

# ---------------------------------------------------------------------------
# The layout registry. Placements are (glyph key, x, y) in reading order;
# "anchor" names the key of the layout's focal glyph — the anvil where an
# anvil is on screen, the pilot-light O everywhere else — which centers
# the anchored partitions (wake, halo, beacon) and ends the routes.
# "anchor_point" is the exact (x, y) the anchored effects radiate from
# (the ember core / the anvil's working face).
# ---------------------------------------------------------------------------
GLYPH_ROWS = {
    "F": CAPS20["F"], "O": O_CORE20, "R": CAPS20["R"],
    "G": CAPS20["G"], "E": CAPS20["E"],
    "F13": CAPS13["F"], "O13": O_CORE13, "R13": CAPS13["R"],
    "G13": CAPS13["G"], "E13": CAPS13["E"],
    "T8": CAPS8["T"], "H8": CAPS8["H"], "E8": CAPS8["E"],
    "F8": CAPS8["F"], "O8": CAPS8["O"], "R8": CAPS8["R"],
    "G8": CAPS8["G"], "E8B": CAPS8["E"],
    "BLOCK": knockout_rows("FORGE", CAPS13, 4, 2, 2, core=O_CORE13),
    "ANVIL": ANVIL_LOGO,
    "ANVIL_XL": ANVIL_XL_LOGO,
}

LAYOUTS = {
    # FORGE at full size, the hero line.
    "line": {
        "glyphs": (("F", 3, 6), ("O", 15, 6), ("R", 27, 6),
                   ("G", 39, 6), ("E", 51, 6)),
        "anchor": "O",
        "anchor_point": (20, 15),
    },
    # The brand-literal knockout: a lit yellow block, unlit letterforms.
    "block": {
        "glyphs": (("BLOCK", 4, 7),),
        "anchor": "BLOCK",
        "anchor_point": (21, 15),          # the pilot light in the O's cell
    },
    # THE small over FORGE large, both flush left.
    "rows": {
        "glyphs": (("T8", 3, 1), ("H8", 9, 1), ("E8", 15, 1),
                   ("F", 3, 10), ("O", 15, 10), ("R", 27, 10),
                   ("G", 39, 10), ("E", 51, 10)),
        "anchor": "O",
        "anchor_point": (20, 19),
    },
    # The forge lockup: the word standing over the stencil anvil it was
    # made on (the strike vignette builds this one, hammer and all).
    "emblem": {
        "glyphs": (("F13", 10, 2), ("O13", 19, 2), ("R13", 28, 2),
                   ("G13", 37, 2), ("E13", 46, 2),
                   ("ANVIL", 21, 19)),
        "anchor": "ANVIL",
        "anchor_point": (31, 20),
    },
    # The big anvil as the hero on the left, THE / FORGE stacked beside.
    "badge": {
        "glyphs": (("ANVIL_XL", 2, 7),
                   ("T8", 39, 6), ("H8", 45, 6), ("E8", 51, 6),
                   ("F8", 33, 16), ("O8", 39, 16), ("R8", 45, 16),
                   ("G8", 51, 16), ("E8B", 57, 16)),
        "anchor": "ANVIL_XL",
        "anchor_point": (16, 9),
    },
}


def layout_slots(name):
    """Every lit pixel of a layout's assembled logo: {(x, y): slot 1..3}."""
    slots = {}
    for key, gx0, gy0 in LAYOUTS[name]["glyphs"]:
        for gy, row in enumerate(GLYPH_ROWS[key]):
            for gx, c in enumerate(row):
                s = CHAR_TO_SLOT[c]
                if s:
                    slots[(gx0 + gx, gy0 + gy)] = s
    return slots


def _shrink(rows):
    """A half-size version of a glyph (every other row/column).
    Index loops, not extended slices: CircuitPython has no step slicing."""
    out = []
    for i in range(0, len(rows), 2):
        row = rows[i]
        out.append("".join(row[j] for j in range(0, len(row), 2)))
    return out


def _mirror(rows):
    """The glyph flipped left-to-right (no step slicing on-device)."""
    out = []
    for row in rows:
        out.append("".join(row[len(row) - 1 - j] for j in range(len(row))))
    return out


def _ease_out(t):
    """Cubic ease-out on t in 0..1."""
    inv = 1.0 - t
    return 1.0 - inv * inv * inv


def _ease_in(t):
    """Cubic ease-in on t in 0..1."""
    return t * t * t


def _white_hot(rows):
    """A glyph's freshly-forged rendering: the yellow body in the
    spark-white slot, so a stamped letter cools by one palette lerp."""
    out = []
    for row in rows:
        out.append("".join("w" if c == "#" else c for c in row))
    return out


# ---------------------------------------------------------------------------
# Swarm variants. SwarmReveal's gradient path precomputes a per-pixel palette
# index map; overriding the index map lets the flock paint the logo's REAL
# colors (yellow strokes, the ember core) instead of a ramp.
# ---------------------------------------------------------------------------

def heat_stop(y, y0, h):
    """HEAT_RAMP index for a panel row: the gradation spans the ink box
    (rows y0 .. y0+h-1) of whatever layout is assembled."""
    stop = (y - y0) * len(HEAT_RAMP) // h
    return min(max(stop, 0), len(HEAT_RAMP) - 1)


def ink_rows(pixels):
    """(top row, row count) of a pixel set's ink box."""
    ys = [p[1] for p in pixels]
    y0 = min(ys)
    return y0, max(ys) - y0 + 1


def _heat_index(slot, y, y0, h):
    """Palette index in the heat swarm's layer for a logo pixel."""
    if slot == 1:
        return 1 + heat_stop(y, y0, h)
    return len(HEAT_RAMP) + (slot - 1)       # core orange/white after ramp


def make_swarm(pixel_slots, heat=False, reverse=False):
    """A SwarmReveal that assembles (or, reversed, carries away) the mark
    in its TRUE colors — flat yellow with the ember core, or the heat
    gradation by row across the layout's ink box."""
    if heat:
        y0, h = ink_rows(pixel_slots)
        colors = HEAT_RAMP + PALETTE_COLORS[2:]
        index_map = {p: _heat_index(slot, p[1], y0, h)
                     for p, slot in pixel_slots.items()}
    else:
        colors = PALETTE_COLORS[1:]
        index_map = dict(pixel_slots)
    return SwarmReveal(list(pixel_slots), bird_color=SPARK_COLOR,
                       num_birds=NUM_BIRDS, bird_speed=2.6,
                       text_colors=colors, index_map=index_map,
                       reverse=reverse)


class ForgeLogoApp(ScrollKitApp):
    """The Forge wordmark, many ways."""

    VERSIONS = ("static", "line", "block", "rows", "emblem", "badge",
                "heat", "temper", "anneal", "strikewake", "heatbloom",
                "beacon", "sparkrain", "shimmer", "caseharden", "hotspots",
                "toolpath", "jobqueue", "worklight",
                "swarm", "drip", "wink",
                "strike", "laser", "sawmill", "sawcut", "print", "weld",
                "wheel", "stitch", "quench", "unforge", "molten",
                "tour", "shuffle")

    def __init__(self, version="static", pitch=None):
        super().__init__(enable_web=False, update_interval=3600)
        self.version = version
        self._pitch = pitch
        self._layout_name = "line"

    async def create_display(self):
        if sys.implementation.name == "circuitpython":
            from scrollkit.display.unified import UnifiedDisplay
            # bit_depth 6 (RGB666): after the panel gamma the dark accents
            # (banked-coal lows, the dim toolpath base) land below RGB444's
            # first step and would crush to black; 6 bits keeps them.
            return UnifiedDisplay(width=64, height=32,   # auto-detects the S3
                                  bit_depth=6)
        from scrollkit.display.simulator import SimulatorDisplay
        if self._pitch:
            return SimulatorDisplay(width=64, height=32, pitch=self._pitch)
        return SimulatorDisplay(width=64, height=32)

    # -- sprite building ----------------------------------------------------

    def _build_tile(self, rows):
        h, w = len(rows), len(rows[0])
        bmp = displayio.Bitmap(w, h, len(ALL_COLORS))
        for y, row in enumerate(rows):
            for x, ch in enumerate(row):
                slot = CHAR_TO_SLOT[ch]
                if slot:
                    bmp[x, y] = slot
        return displayio.TileGrid(bmp, pixel_shader=self._palette)

    def _build_sprites(self):
        # Shared palette: slots 0-3 are the flat logo colors, slots 4-8 hold
        # the heat gradation (animated by palette writes, never redraws),
        # slots 9-11 the tool material shades (never animated by effects).
        self._palette = displayio.Palette(len(ALL_COLORS))
        for i, color in enumerate(ALL_COLORS):
            self._palette[i] = color
        self._palette.make_transparent(0)

        # Every glyph a layout can place, keyed as in LAYOUTS.
        self.glyph_tiles = {}
        for key, rows in GLYPH_ROWS.items():
            self.glyph_tiles[key] = self._build_tile(rows)

        # The strike vignette's actors: the steel anvil and the hammer's
        # three arc poses (cel-cycled UP -> MID -> DOWN), plus the
        # three-frame impact flash.
        self.steel_anvil = self._build_tile(ANVIL)
        self.hammer = [self._build_tile(rows)
                       for rows in (HAMMER_UP, HAMMER_MID, HAMMER_DOWN)]
        self.burst = [self._build_tile(rows)
                      for rows in (SPARK_BURST_A, SPARK_BURST_B,
                                   SPARK_BURST_C)]

        # White-hot stamp tiles for the strike vignette (see _white_hot).
        self.hot13 = {}
        for key in ("F13", "O13", "R13", "G13", "E13"):
            self.hot13[key] = self._build_tile(_white_hot(GLYPH_ROWS[key]))

        # The rest of the shop: laser carriage, saw + board, MIG torch,
        # potter's wheel + clay poses, sewing machine + its stitch dashes,
        # and the shared gantry rail / saw table strips.
        self.laser_head = self._build_tile(LASER_HEAD)
        self.rail = self._build_tile(["d" * 64])
        self.table = self._build_tile(["d" * 48, "d" * 48])
        self.saw = [self._build_tile(SAW_A), self._build_tile(SAW_B)]
        self.board = [self._build_tile(BOARD_L), self._build_tile(BOARD_R)]
        self.torch = self._build_tile(TORCH)
        self.wheel = [self._build_tile(WHEEL_A), self._build_tile(WHEEL_B)]
        self.clay = [self._build_tile(rows)
                     for rows in (CLAY_1, CLAY_2, CLAY_3, CLAY_4)]
        self.pot_hot = self._build_tile(POT_HOT)
        self.sewer = [self._build_tile(SEWER_A), self._build_tile(SEWER_B)]
        self.dashes = [self._build_tile(["###"]) for _ in range(11)]

        self._slots_by_layout = {name: layout_slots(name) for name in LAYOUTS}

        self._all_tiles = (
            list(self.glyph_tiles.values())
            + [self.steel_anvil]
            + self.hammer
            + self.burst
            + list(self.hot13.values())
            + [self.laser_head, self.rail, self.table, self.torch,
               self.pot_hot]
            + self.saw + self.board + self.wheel + self.clay + self.sewer
            + self.dashes
        )
        for tile in self._all_tiles:
            tile.hidden = True
            self.display.add_layer(tile)

        # The spark pool: a handful of tiny 1-LED sparks sharing one
        # 3-color palette, flown along precomputed ballistic arcs and
        # faded by palette writes on the shared palette.
        self._spark_palette = displayio.Palette(2)
        self._spark_palette.make_transparent(0)
        self._spark_palette[1] = panel_color(0xFFF6D8)
        self.sparks = []
        for _ in range(10):
            bmp = displayio.Bitmap(1, 1, 2)
            bmp[0, 0] = 1
            tile = displayio.TileGrid(bmp, pixel_shader=self._spark_palette)
            tile.hidden = True
            self.display.add_layer(tile)
            self._all_tiles.append(tile)
            self.sparks.append(tile)

        # Ballistic arc tables for the spark pool, one per spark, built
        # once: runtime flight is table lookups + tile moves, and the
        # whole shower fades with single writes on the shared palette.
        self._spark_arcs = []
        for _ in self.sparks:
            ang = math.pi * (0.25 + 0.5 * random.random())   # fan upward
            speed = 1.2 + 1.6 * random.random()
            vx = math.cos(ang) * speed
            vy = math.sin(ang) * speed
            arc = []
            for t in range(15):
                arc.append((int(round(vx * t)),
                            int(round(-vy * t + 0.09 * t * t))))
            self._spark_arcs.append(arc)
        self._spark_live = []
        self._spark_age = 0
        self._spark_rot = 0

        # The laser beam (1x17, its own red palette) and the welding arc
        # (two 2x2 blue-white tiles alternated for a soft shimmer).
        self._beam_pal = displayio.Palette(2)
        self._beam_pal.make_transparent(0)
        self._beam_pal[1] = LASER_RED
        beam_bmp = displayio.Bitmap(1, 17, 2)
        for yy in range(17):
            beam_bmp[0, yy] = 1
        self.beam = displayio.TileGrid(beam_bmp, pixel_shader=self._beam_pal)
        self.arc = []
        for color in (ARC_BRIGHT, ARC_HALO):
            pal = displayio.Palette(2)
            pal.make_transparent(0)
            pal[1] = color
            bmp = displayio.Bitmap(2, 2, 2)
            for xx in range(2):
                for yy in range(2):
                    bmp[xx, yy] = 1
            self.arc.append(displayio.TileGrid(bmp, pixel_shader=pal))
        for tile in [self.beam] + self.arc:
            tile.hidden = True
            self.display.add_layer(tile)
            self._all_tiles.append(tile)

        # The saw kerf: an opaque black 64x1 line that erases the mark
        # behind the crossing blade (revealed by the x-offset trick).
        kerf_pal = displayio.Palette(2)
        kerf_pal.make_transparent(0)
        kerf_pal[1] = 0x000000
        kerf_bmp = displayio.Bitmap(64, 1, 2)
        for xx in range(64):
            kerf_bmp[xx, 0] = 1
        self.kerf = displayio.TileGrid(kerf_bmp, pixel_shader=kerf_pal)
        self.kerf.hidden = True
        self.display.add_layer(self.kerf)
        self._all_tiles.append(self.kerf)

        # Per-layout resources built on first use (each lazy add_layer call
        # lands ABOVE everything so far; all of these show while the glyph
        # sprites are hidden, so stacking among them never matters).
        self._fx_cache = {}          # (layout, partition name) -> PalettePartition
        self._heat_tiles = {}        # layout -> gradient logo tile
        self._aperture_masks = {}    # layout -> holes-for-strokes mask tile
        self._glyph_paths_cache = {} # layout -> per-letter BFS stroke paths

    # -- the active layout and its lazy resources ---------------------------

    @property
    def _logo_slots(self):
        """Lit pixels of the ACTIVE layout's assembled mark."""
        return self._slots_by_layout[self._layout_name]

    def _set_layout(self, name):
        """Switch the active composition. Only while the panel is empty:
        scenes always build, dwell, and exit within one layout."""
        self._layout_name = name

    def _anchor_point(self):
        """The exact (x, y) the anchored effects radiate from."""
        return LAYOUTS[self._layout_name]["anchor_point"]

    def _hide_glyphs(self):
        """Hide every wordmark sprite (whatever layout placed them)."""
        for tile in self.glyph_tiles.values():
            tile.hidden = True

    def _heat_tile(self):
        """The active layout's gradient logo (lazy): one full-panel bitmap
        where each yellow pixel takes a HEAT_RAMP slot by row across the
        layout's ink box. The ember core keeps its orange/white slots."""
        tile = self._heat_tiles.get(self._layout_name)
        if tile is None:
            slots = self._logo_slots
            y0, h = ink_rows(slots)
            grad = displayio.Bitmap(64, 32, len(ALL_COLORS))
            for (x, y), slot in slots.items():
                grad[x, y] = 4 + heat_stop(y, y0, h) if slot == 1 else slot
            tile = displayio.TileGrid(grad, pixel_shader=self._palette)
            tile.hidden = True
            self.display.add_layer(tile)
            self._all_tiles.append(tile)
            self._heat_tiles[self._layout_name] = tile
        return tile

    def _aperture_tile(self):
        """The active layout's aperture mask (lazy): opaque black over the
        WHOLE panel with transparent holes at exactly the logo's lit
        pixels — the wordmark as a window."""
        mask_tile = self._aperture_masks.get(self._layout_name)
        if mask_tile is None:
            mask = displayio.Bitmap(64, 32, 2)
            try:
                mask.fill(1)
            except (AttributeError, TypeError):
                for mx in range(64):
                    for my in range(32):
                        mask[mx, my] = 1
            for (x, y) in self._logo_slots:
                mask[x, y] = 0
            mask_pal = displayio.Palette(2)
            mask_pal.make_transparent(0)
            mask_pal[1] = 0x000000
            mask_tile = displayio.TileGrid(mask, pixel_shader=mask_pal)
            mask_tile.hidden = True
            self.display.add_layer(mask_tile)
            self._all_tiles.append(mask_tile)
            self._aperture_masks[self._layout_name] = mask_tile
        return mask_tile

    def _laser_sheet(self):
        """The uncut steel plate for the laser vignette (lazy): the block's
        exact footprint with the letter strokes filled in, letter pixels
        banded by column so the cut is a palette sweep."""
        tile = getattr(self, "_sheet_tile", None)
        if tile is None:
            rows = GLYPH_ROWS["BLOCK"]
            w = len(rows[0])
            bmp = displayio.Bitmap(w, len(rows), 14)
            for y, row in enumerate(rows):
                for x, c in enumerate(row):
                    bmp[x, y] = 1 if c != "." else 2 + min(
                        x * 12 // w, 11)
            pal = displayio.Palette(14)
            pal.make_transparent(0)
            self._sheet_pal = pal
            tile = displayio.TileGrid(bmp, pixel_shader=pal)
            tile.x, tile.y = 4, 7
            tile.hidden = True
            self.display.add_layer(tile)
            self._all_tiles.append(tile)
            self._sheet_tile = tile
        return tile

    def _half_tiles(self):
        """The active layout's mark as two bitmaps split at the ink box's
        midline (lazy), for the saw-cut exit."""
        pair = getattr(self, "_half_cache", {}).get(self._layout_name)
        if pair is None:
            slots = self._logo_slots
            y0, h = ink_rows(slots)
            mid = y0 + h // 2
            tiles = []
            for half in (0, 1):
                bmp = displayio.Bitmap(64, 32, len(ALL_COLORS))
                for (x, y), slot in slots.items():
                    if (y < mid) == (half == 0):
                        bmp[x, y] = slot
                tile = displayio.TileGrid(bmp, pixel_shader=self._palette)
                tile.hidden = True
                self.display.add_layer(tile)
                self._all_tiles.append(tile)
                tiles.append(tile)
            pair = (tiles[0], tiles[1], mid)
            if not hasattr(self, "_half_cache"):
                self._half_cache = {}
            self._half_cache[self._layout_name] = pair
        return pair

    def _molten_tile(self):
        """A 64x64 banded heat-glow backdrop (lazy) swept behind the
        aperture mask — molten light seen through the mark's strokes."""
        tile = getattr(self, "_molten_bg", None)
        if tile is None:
            stops = (HEAT_RAMP[0], HEAT_RAMP[0], HEAT_RAMP[1], HEAT_RAMP[2],
                     HEAT_RAMP[3], HEAT_RAMP[4], HEAT_RAMP[4], HEAT_RAMP[3],
                     HEAT_RAMP[2], HEAT_RAMP[1], HEAT_RAMP[0], 0x000000,
                     HEAT_RAMP[0], HEAT_RAMP[1], HEAT_RAMP[1], 0x000000)
            bmp = displayio.Bitmap(64, 64, len(stops) + 1)
            for y in range(64):
                band = 1 + (y * len(stops)) // 64
                for x in range(64):
                    bmp[x, y] = band
            pal = displayio.Palette(len(stops) + 1)
            pal.make_transparent(0)
            for i, c in enumerate(stops):
                pal[1 + i] = c
            tile = displayio.TileGrid(bmp, pixel_shader=pal)
            tile.hidden = True
            self.display.add_layer(tile)
            self._all_tiles.append(tile)
            self._molten_bg = tile
        return tile

    # -- frame helpers -------------------------------------------------------

    async def _frame(self):
        """Present one frame at ~20 fps. False means the window closed."""
        if await self.display.show() is False:
            return False
        await asyncio.sleep(0.05)
        return True

    async def _hold(self, frames):
        for _ in range(frames):
            if not self.running or not await self._frame():
                return False
        return True

    def _hide_all(self):
        for tile in self._all_tiles:
            tile.hidden = True
        self._logo_mode = None
        self._spark_live = []

    # -- vignette actors: hammer, impact flash, the spark pool ---------------

    def _raise_actors(self):
        """Re-stack the vignette cast above everything else. Lazy layers
        (fx partitions, the laser sheet, the mark's halves, heat tiles)
        are added above whatever exists at the time, so every vignette
        lifts its actors back to the top before the curtain rises."""
        actors = ([self.table] + self.board + [self.steel_anvil]
                  + self.wheel + self.clay + [self.pot_hot]
                  + self.sewer + self.dashes
                  + [self.rail, self.laser_head, self.torch]
                  + self.saw + [self.kerf, self.beam] + self.arc
                  + self.burst + self.hammer + self.sparks)
        for tile in actors:
            self.display.remove_layer(tile)
            self.display.add_layer(tile)

    def _hammer_pose(self, pose, x, y):
        """Show one arc pose of the hammer (0 up, 1 mid, 2 contact)."""
        for i, tile in enumerate(self.hammer):
            if i == pose:
                tile.x, tile.y = x, y
                tile.hidden = False
            else:
                tile.hidden = True

    def _hide_hammer(self):
        for tile in self.hammer:
            tile.hidden = True

    def _burst_pose(self, frame, x, y):
        """One expansion frame of the impact flash (A->B->C, then gone)."""
        for i, tile in enumerate(self.burst):
            if i == frame:
                tile.x, tile.y = x, y
                tile.hidden = False
            else:
                tile.hidden = True

    def _saw_pose(self, frame, x, y, rate=2):
        """Spin the blade: the two tooth phases swap every ``rate`` frames."""
        a, b = self.saw
        show, hide = (a, b) if (frame // rate) % 2 == 0 else (b, a)
        show.x, show.y = x, y
        show.hidden = False
        hide.hidden = True

    def _hide_saw(self):
        for tile in self.saw:
            tile.hidden = True

    def _wheel_pose(self, frame, x, y):
        """Spin the potter's wheel: dash phases swap every 2 frames."""
        a, b = self.wheel
        show, hide = (a, b) if (frame // 2) % 2 == 0 else (b, a)
        show.x, show.y = x, y
        show.hidden = False
        hide.hidden = True

    def _sewer_pose(self, frame, x, y):
        """The sewing machine's stitch cycle: needle up / needle down."""
        a, b = self.sewer
        show, hide = (a, b) if (frame // 3) % 2 == 0 else (b, a)
        show.x, show.y = x, y
        show.hidden = False
        hide.hidden = True

    def _hide_sewer(self):
        for tile in self.sewer:
            tile.hidden = True

    def _launch_sparks(self, x0, y0, n, color=None):
        """Fire n pool sparks from (x0, y0) along their prebuilt arcs.
        A new shower retires the previous one (the impact flash covers
        the cut); the launch rotates through the arc tables for variety.
        ``color`` overrides the white-hot birth color (sawdust, steam);
        an overridden shower keeps its color for its whole flight."""
        for tile in self.sparks:
            tile.hidden = True
        self._spark_live = []
        self._spark_age = 0
        self._spark_hold = color is not None
        self._spark_palette[1] = color or PALETTE_COLORS[3]
        for j in range(n):
            idx = (self._spark_rot + j) % len(self.sparks)
            tile = self.sparks[idx]
            tile.x, tile.y = x0, y0
            tile.hidden = False
            self._spark_live.append((tile, self._spark_arcs[idx], x0, y0))
        self._spark_rot = (self._spark_rot + n) % len(self.sparks)

    def _step_sparks(self):
        """Advance the live shower one frame: tile moves plus at most one
        palette write (the whole shower cools white -> hot -> orange)."""
        if not self._spark_live:
            return
        self._spark_age += 1
        age = self._spark_age
        if age >= 14:
            for tile, _arc, _sx, _sy in self._spark_live:
                tile.hidden = True
            self._spark_live = []
            return
        if not getattr(self, "_spark_hold", False):
            if age == 5:
                self._spark_palette[1] = SPARK_MID
            elif age == 10:
                self._spark_palette[1] = PALETTE_COLORS[2]
        for tile, arc, sx, sy in self._spark_live:
            dx, dy = arc[age]
            tile.x = sx + dx
            tile.y = sy + dy

    def _show_logo(self):
        """Everything in its final place (the flat brand-yellow version)."""
        for key, x, y in LAYOUTS[self._layout_name]["glyphs"]:
            tile = self.glyph_tiles[key]
            tile.x, tile.y = x, y
            tile.hidden = False
        self._logo_mode = "flat"

    def _show_heat_logo(self, ramp=None):
        """The gradient logo, in place; the ramp lives in palette slots."""
        self._heat_ramp = ramp or HEAT_RAMP
        self._paint_ramp(self._heat_ramp)
        self._heat_tile().hidden = False
        self._logo_mode = "heat"

    async def _pilot_flare(self):
        """The mark's micro-event (the owl blink's forge-side equivalent):
        the pilot light pops white-hot and the yellow warms a step for a
        beat. A single localized event — visible on every layout,
        including the knockout block."""
        self._palette[1] = self._lerp_color(PALETTE_COLORS[1],
                                            PALETTE_COLORS[3], 0.3)
        self._palette[2] = PALETTE_COLORS[3]
        if not await self._hold(3):
            return False
        self._palette[1] = PALETTE_COLORS[1]
        self._palette[2] = PALETTE_COLORS[2]
        return True

    async def _dwell(self):
        """The standard admire-the-logo beat: hold, flare, hold."""
        if not await self._hold(16):
            return False
        if not await self._pilot_flare():
            return False
        return await self._hold(10)

    def _set_core_palette(self, orange, white):
        self._palette[2] = orange
        self._palette[3] = white

    @staticmethod
    def _lerp_color(a, b, t):
        """Linear blend of two 0xRRGGBB colors at t in 0..1."""
        channels = []
        for shift in (16, 8, 0):
            ca = (a >> shift) & 0xFF
            cb = (b >> shift) & 0xFF
            channels.append(int(ca + (cb - ca) * t) & 0xFF)
        return (channels[0] << 16) | (channels[1] << 8) | channels[2]

    # -- the heat gradation as a reusable layer ------------------------------

    def _paint_ramp(self, colors):
        """Write the gradation's palette slots (4..8). Zero pixel work."""
        for i, c in enumerate(colors):
            self._palette[4 + i] = c

    async def _to_heat(self, ramp=None):
        """The gradation develops into whatever flat logo is on screen:
        an invisible tile swap (ramp slots painted flat yellow), then the
        stops lerp out to the ramp. Random fired-from-below / from-above."""
        if self._logo_mode == "heat":
            return True
        ramp = ramp or (HEAT_RAMP if random.random() < 0.5
                        else tuple(reversed(HEAT_RAMP)))
        self._paint_ramp((PALETTE_COLORS[1],) * len(ramp))
        self._hide_glyphs()
        self._heat_tile().hidden = False
        self._logo_mode = "heat"
        self._heat_ramp = ramp
        develop = 16
        for f in range(develop + 1):
            t = f / develop
            self._paint_ramp(tuple(
                self._lerp_color(PALETTE_COLORS[1], c, t) for c in ramp))
            if not await self._frame():
                return False
        return True

    async def _to_flat(self):
        """The gradation settles back to flat yellow, then swaps to
        sprites — the metal cools through brand yellow and stops there."""
        if self._logo_mode != "heat":
            return True
        ramp = getattr(self, "_heat_ramp", HEAT_RAMP)
        settle = 14
        for f in range(settle + 1):
            t = f / settle
            self._paint_ramp(tuple(
                self._lerp_color(c, PALETTE_COLORS[1], t) for c in ramp))
            if not await self._frame():
                return False
        self._heat_tile().hidden = True
        self._show_logo()
        self._paint_ramp(HEAT_RAMP)
        return True

    async def _heat_breathe(self, frames, flare_at=()):
        """Each ramp stop drifts toward its hotter neighbour and back,
        phase-staggered so warmth rolls slowly through the mark."""
        ramp = getattr(self, "_heat_ramp", HEAT_RAMP)
        n = len(ramp)
        for f in range(frames):
            tt = f * 0.05
            self._paint_ramp(tuple(
                self._lerp_color(ramp[i], ramp[min(i + 1, n - 1)],
                                 (0.5 + 0.5 * math.sin(tt * 2.4 + i * 0.9)) * 0.55)
                for i in range(n)))
            if f in flare_at:
                if not await self._pilot_flare():
                    return False
            elif not await self._frame():
                return False
        return True

    async def _dwell_here(self):
        """Dwell in whatever mode the logo is currently shown."""
        if self._logo_mode == "heat":
            return await self._heat_breathe(46, flare_at=(18,))
        return await self._dwell()

    # -- partitioned palette effects (the heat trick, generalized) -----------

    def _glyph_body_pixels(self, key, gx0, gy0):
        """The lit yellow pixels of one placed glyph."""
        pixels = set()
        for gy, row in enumerate(GLYPH_ROWS[key]):
            for gx, c in enumerate(row):
                if CHAR_TO_SLOT[c] == 1:
                    pixels.add((gx0 + gx, gy0 + gy))
        return pixels

    def _letter_body_sets(self):
        """Per-letter sets of lit pixels for the ACTIVE layout, in reading
        order (every placed glyph except the layout's anchor)."""
        lay = LAYOUTS[self._layout_name]
        return [self._glyph_body_pixels(key, x, y)
                for key, x, y in lay["glyphs"] if key != lay["anchor"]]

    def _fx(self, name):
        """Build (once per layout) and return a named PalettePartition."""
        key = (self._layout_name, name)
        fx = self._fx_cache.get(key)
        if fx is not None:
            return fx
        ax, ay = self._anchor_point()
        if name == "diag":
            group_map, n = map_diagonal(self._logo_slots, 10)
        elif name == "wake":
            group_map, n = map_anchor_distance(self._logo_slots, ax, 10)
        elif name == "topo":
            group_map, n = map_topology(self._logo_slots)
        elif name == "radial":
            group_map, n = map_radial(self._logo_slots, ax, ay, 10)
        elif name == "angle":
            group_map, n = map_angle(self._logo_slots, ax, ay, 14)
        elif name == "rain":
            group_map, n = map_rain(self._logo_slots, 10)
        elif name == "checker":
            group_map, n = map_checker(self._logo_slots, 4)
        elif name == "exposure":
            group_map, n = map_exposure(self._logo_slots)
        elif name == "regions":
            group_map, n = map_regions(self._logo_slots, 10)
        elif name == "printrows":
            # Horizontal bands bottom-up for the 3D-printer build: the
            # nozzle lays the mark down one band per pass.
            y0, h = ink_rows(self._logo_slots)
            bands = 7
            group_map = {}
            for p, slot in self._logo_slots.items():
                if slot == 1:
                    group_map[p] = min((p[1] - y0) * bands // h, bands - 1)
            n = bands
        elif name == "weldseam":
            # The block's perimeter in path order (16 bead segments) plus
            # the whole interior as one flood group, for the MIG build.
            xs = [p[0] for p in self._logo_slots]
            ys = [p[1] for p in self._logo_slots]
            x0, x1 = min(xs), max(xs)
            y0, y1 = min(ys), max(ys)
            path = []
            for x in range(x0, x1 + 1):
                path.append((x, y0))
            for y in range(y0 + 1, y1 + 1):
                path.append((x1, y))
            for x in range(x1 - 1, x0 - 1, -1):
                path.append((x, y1))
            for y in range(y1 - 1, y0, -1):
                path.append((x0, y))
            self._weld_path = path
            group_map = {}
            for i, p in enumerate(path):
                if p in self._logo_slots:
                    group_map[p] = i * 16 // len(path)
            for p, slot in self._logo_slots.items():
                if slot == 1 and p not in group_map:
                    group_map[p] = 16
            n = 17
        elif name == "route":
            lay = LAYOUTS[self._layout_name]
            anchor_body = set()
            for gkey, gx, gy in lay["glyphs"]:
                if gkey == lay["anchor"]:
                    anchor_body = self._glyph_body_pixels(gkey, gx, gy)
            group_map, n = map_route(self._logo_slots,
                                     self._letter_body_sets(), anchor_body)
        else:
            raise ValueError(name)
        fx = PalettePartition(
            displayio, self._logo_slots, group_map, n,
            identity_colors=(PALETTE_COLORS[2], PALETTE_COLORS[3]))
        self.display.add_layer(fx.tile)
        self._all_tiles.append(fx.tile)
        self._fx_cache[key] = fx
        return fx

    def _layout_glyph_paths(self):
        """The ACTIVE layout's per-letter BFS stroke paths (cached)."""
        paths = self._glyph_paths_cache.get(self._layout_name)
        if paths is None:
            paths = bfs_paths(self._letter_body_sets())
            self._glyph_paths_cache[self._layout_name] = paths
        return paths

    async def _fx_treatment(self, name, make):
        """Run a library palette treatment on the flat logo: invisible tile
        swap in, drive it frame by frame (flaring on its blink beats),
        swap back. ``make(fx)`` returns the treatment instance."""
        fx = self._fx(name)
        fx.fill(PALETTE_COLORS[1])
        fx.set_identity(PALETTE_COLORS[2], PALETTE_COLORS[3])
        self._hide_glyphs()
        fx.tile.hidden = False
        t = make(fx)
        if hasattr(t, "start"):
            t.start(self.display)                # PacketTrace's sprites
        ok = await self._run_treatment(t, fx)
        if hasattr(t, "detach"):
            t.detach()
        fx.tile.hidden = True
        self._show_logo()
        return ok

    async def _run_treatment(self, t, fx):
        """The treatment driver: one step per frame; the treatment's blink
        beats replace that frame's present with the pilot flare."""
        while not t.is_complete:
            t.step()
            if t.is_complete:
                break
            if t.blink_now:
                if not await self._fx_flare(fx):
                    return False
            elif not await self._frame():
                return False
        return True

    async def _fx_flare(self, fx):
        """A pilot flare on an effect layer's own palette (identity slots
        only — the group colors are mid-treatment and stay untouched)."""
        fx.set_identity(PALETTE_COLORS[3], PALETTE_COLORS[3])
        if not await self._hold(3):
            return False
        fx.set_identity(PALETTE_COLORS[2], PALETTE_COLORS[3])
        return True

    # -- treatment factories (library classes + this app's colors/routes) ----

    def _temper_make(self, edition=None):
        """One Temper Library chapter: a GradientDwell edition. A random
        edition is drawn at treatment start when none is given."""
        def make(fx):
            lo, hi = edition or TEMPER_EDITIONS[
                random.randrange(len(TEMPER_EDITIONS))]
            return GradientDwell(fx, HEAT_RAMP, lo, hi)
        return make

    def _toolpath_make(self):
        """The CNC toolpath: hot packets crawl the strokes to the anchor."""
        def make(fx):
            left, right = self._route_split()
            routes = ([s for i in left for s in range(3 * i, 3 * i + 3)],
                      [s for i in right for s in range(3 * i, 3 * i + 3)])
            return RouteCircuit(fx, HEAT_RAMP, routes,
                                base_color=CIRCUIT_BASE)
        return make

    def _jobqueue_make(self):
        """Packet dots walk the letter paths like queued jobs."""
        def make(fx):
            left, right = self._route_split()
            runs = ((left, 0), (left, -30), (right, 0), (right, -24))
            return PacketTrace(fx, HEAT_RAMP, self._layout_glyph_paths(),
                               runs, packet_color=PALETTE_COLORS[2],
                               base_color=CIRCUIT_BASE)
        return make

    def _route_split(self):
        """Letter indices for the two converging packet runs: the letters
        before the anchor in reading order, then the rest walked backward.
        When the anchor LEADS the composition (emblem, badge), the word is
        split at its midpoint instead so packets come from both ends."""
        lay = LAYOUTS[self._layout_name]
        keys = [k for k, _x, _y in lay["glyphs"]]
        n_letters = len(keys) - 1
        n_before = keys.index(lay["anchor"])
        if n_before in (0, n_letters):
            n_before = (n_letters + 1) // 2
        left = tuple(range(n_before))
        right = tuple(range(n_letters - 1, n_before - 1, -1))
        return left, right

    # -- building blocks: library transitions + splashes ---------------------

    async def _swap_via(self, name, rearrange):
        """Drive one of scrollkit's screen transitions: the pattern covers
        the panel, ``rearrange`` runs while hidden, the pattern reveals the
        result."""
        tr = _TRANSITION_MAP[name]()
        await tr.start(self.display, rearrange)
        while not tr.is_complete:
            if not self.running:
                tr.detach()
                return False
            await tr.render(self.display)
            if not await self._frame():
                tr.detach()
                return False
        return True

    async def _reveal_logo_via(self, name, heat=False):
        """Empty panel -> the pattern wipes the assembled logo in (flat
        yellow, or carrying the heat gradation)."""
        self._hide_all()
        rearrange = self._show_heat_logo if heat else self._show_logo
        return await self._swap_via(name, rearrange)

    async def _hide_logo_via(self, name):
        """Assembled logo -> the pattern wipes it out to an empty panel."""
        return await self._swap_via(name, self._hide_all)

    async def _drip_in(self, direction="top"):
        """The logo's pixels rain in from an edge (flat yellow), then the
        true colors pop when the overlay hands off to the sprite layers."""
        self._hide_all()
        drip = DripReveal(list(self._logo_slots), color=PALETTE_COLORS[1],
                          fall_speed=2, stagger=1, direction=direction)
        drip.start(self.display)
        steps = 0
        ok = True
        while not drip.step() and steps < 2500:
            steps += 1
            if not self.running or not await self._frame():
                ok = False
                break
        if ok:
            self._show_logo()      # same pixels underneath, then lift the
        drip.detach()              # overlay: the pilot light pops in
        return ok

    async def _wink_in(self, heat=False):
        """Every LED lights brand yellow, then non-logo pixels wink off
        until only the mark remains; the overlay lifts and the ember core
        pops (and, in the heat variant, the gradation is revealed)."""
        if heat:
            self._show_heat_logo()  # in place beneath the yellow wall
        else:
            self._show_logo()
        ok = await show_reveal_splash(self.display, list(self._logo_slots),
                                      color=PALETTE_COLORS[1],
                                      off_per_frame=44, hold_seconds=0.6)
        return ok is not False and self.running

    async def _run_swarm(self, swarm, max_steps=2500):
        """Drive a swarm to completion; caller detaches. False on close."""
        swarm.start(self.display)
        steps = 0
        while not swarm.is_complete and steps < max_steps and self.running:
            swarm.step()
            steps += 1
            if not await self._frame():
                return False
        return True

    async def _swarm_build(self, heat=False):
        """Just the assemble half of the swarm scene. The heat variant has
        the flock deliver the gradient version stop by stop."""
        self._hide_all()
        swarm = make_swarm(self._logo_slots, heat=heat)
        ok = await self._run_swarm(swarm)
        if ok:
            if heat:
                self._show_heat_logo()
            else:
                self._show_logo()
        swarm.detach()
        return ok

    async def _swarm_unbuild(self):
        """Just the deconstruct half, matching however the logo is shown."""
        heat = self._logo_mode == "heat"
        self._hide_all()
        unswarm = make_swarm(self._logo_slots, heat=heat, reverse=True)
        ok = await self._run_swarm(unswarm)
        unswarm.detach()
        return ok

    # -- the strike vignette: hammer + anvil forge the wordmark --------------

    async def _strike_build(self):
        """The signature build. The steel anvil drops in and lands in a
        spark puff; the hammer forges the wordmark white-hot above it —
        one letter per clang, R and G together on the finale — then the
        letters cool through pale gold to brand yellow and the anvil
        takes the brand too. Ends exactly on the emblem layout."""
        self._set_layout("emblem")
        self._hide_all()
        self._raise_actors()
        anvil = self.steel_anvil
        face_x, face_y = 31, 19          # the working face's contact point

        # The anvil drops from above and lands with a puff of sparks.
        drop = 12
        for f in range(drop + 1):
            t = _ease_in(f / drop)
            anvil.x = 21
            anvil.y = int(round(-13 + 32 * t))
            anvil.hidden = False
            if not await self._frame():
                return False
        self._launch_sparks(face_x, face_y, 6)
        for f in range(8):
            self._burst_pose(f, face_x - 5, face_y - 4)
            self._step_sparks()
            if not await self._frame():
                return False

        # The hammer slides in and parks high over the face.
        enter = 8
        for f in range(enter + 1):
            t = _ease_out(f / enter)
            self._hammer_pose(0, int(round(66 + (28 - 66) * t)), 9)
            self._step_sparks()
            if not await self._frame():
                return False

        # Four strikes forge the word: F, O, E, then R + G on the finale
        # (the letters under the hammer's parking spot stamp last).
        letters = [g for g in LAYOUTS["emblem"]["glyphs"]
                   if g[0] != "ANVIL"]
        for stamp in ((0,), (1,), (4,), (2, 3)):
            for _ in range(5):                       # windup, hammer high
                self._hammer_pose(0, 28, 9)
                self._step_sparks()
                if not await self._frame():
                    return False
            self._hammer_pose(1, 28, 9)              # mid-swing
            self._step_sparks()
            if not await self._frame():
                return False
            # Contact: flash, shower, and the letters stamp in white-hot.
            self._launch_sparks(face_x, face_y, 8)
            for i in stamp:
                key, x, y = letters[i]
                tile = self.hot13[key]
                tile.x, tile.y = x, y
                tile.hidden = False
            for f in range(3):
                self._hammer_pose(2, 28, 9)
                self._burst_pose(f, face_x - 5, face_y - 4)
                self._step_sparks()
                if not await self._frame():
                    return False
            self._burst_pose(3, 0, 0)
            self._hammer_pose(1, 28, 9)              # recover through mid
            self._step_sparks()
            if not await self._frame():
                return False

        # The hammer leaves, up and off to the right.
        for f in range(9):
            t = _ease_in(f / 8)
            self._hammer_pose(0, int(round(28 + 40 * t)),
                              int(round(9 - 12 * t)))
            self._step_sparks()
            if not await self._frame():
                return False
        self._hide_hammer()

        # The forged letters cool: white-hot through pale gold to brand
        # yellow — one palette slot, every stamped letter at once.
        cool = 20
        for f in range(cool + 1):
            t = f / cool
            self._palette[3] = self._lerp_color(PALETTE_COLORS[3],
                                                PALETTE_COLORS[1], t)
            self._step_sparks()
            if not await self._frame():
                return False

        # The anvil takes the brand: steel lerps to yellow, then the
        # sprite swap lands the real emblem — the pilot light and the
        # face ember pop in.
        transmute = 10
        for f in range(transmute + 1):
            t = f / transmute
            self._palette[9] = self._lerp_color(MATERIAL_SHADES[0],
                                                PALETTE_COLORS[1], t)
            self._palette[10] = self._lerp_color(MATERIAL_SHADES[1],
                                                 PALETTE_COLORS[1], t)
            if not await self._frame():
                return False
        for tile in self.hot13.values():
            tile.hidden = True
        anvil.hidden = True
        self._show_logo()
        self._palette[3] = PALETTE_COLORS[3]
        self._palette[9] = MATERIAL_SHADES[0]
        self._palette[10] = MATERIAL_SHADES[1]
        return True

    async def _unforge_exit(self):
        """The strike's exit twin (emblem only): the hammer returns and
        knocks the letters back out in reverse — each clang bursts a
        letter into sparks — then the anvil reverts to steel and sinks."""
        self._raise_actors()
        letters = [g for g in LAYOUTS["emblem"]["glyphs"]
                   if g[0] != "ANVIL"]
        enter = 8
        for f in range(enter + 1):
            t = _ease_out(f / enter)
            self._hammer_pose(0, int(round(66 + (28 - 66) * t)), 9)
            if not await self._frame():
                return False
        for stamp in ((2, 3), (4,), (1,), (0,)):
            for _ in range(4):
                self._hammer_pose(0, 28, 9)
                self._step_sparks()
                if not await self._frame():
                    return False
            self._hammer_pose(1, 28, 9)
            self._step_sparks()
            if not await self._frame():
                return False
            key, lx, ly = letters[stamp[0]]
            self._launch_sparks(lx + 4, ly + 6, 8)
            for i in stamp:
                self.glyph_tiles[letters[i][0]].hidden = True
            for f in range(3):
                self._hammer_pose(2, 28, 9)
                self._burst_pose(f, lx - 1, ly + 3)
                self._step_sparks()
                if not await self._frame():
                    return False
            self._burst_pose(3, 0, 0)
        for f in range(9):
            t = _ease_in(f / 8)
            self._hammer_pose(0, int(round(28 + 40 * t)),
                              int(round(9 - 12 * t)))
            self._step_sparks()
            if not await self._frame():
                return False
        self._hide_hammer()
        # The anvil un-brands — yellow back to steel — and sinks away.
        self._palette[9] = PALETTE_COLORS[1]
        self._palette[10] = PALETTE_COLORS[1]
        self.glyph_tiles["ANVIL"].hidden = True
        anvil = self.steel_anvil
        anvil.x, anvil.y = 21, 19
        anvil.hidden = False
        revert = 10
        for f in range(revert + 1):
            t = f / revert
            self._palette[9] = self._lerp_color(
                PALETTE_COLORS[1], MATERIAL_SHADES[0], t)
            self._palette[10] = self._lerp_color(
                PALETTE_COLORS[1], MATERIAL_SHADES[1], t)
            if not await self._frame():
                return False
        sink = 10
        for f in range(sink + 1):
            t = _ease_in(f / sink)
            anvil.y = 19 + int(round(14 * t))
            if not await self._frame():
                return False
        self._hide_all()
        return True

    # -- the laser vignette: the head cuts FORGE out of steel plate ----------

    async def _laser_build(self):
        """Block-layout build. A gray steel plate fades in; the laser
        carriage rides the gantry across it, the red beam cutting the
        letterforms dark column by column under a rising spark plume;
        the finished piece flips brand yellow — the plate IS the mark."""
        self._set_layout("block")
        self._hide_all()
        sheet = self._laser_sheet()
        self._raise_actors()           # after the lazy sheet, above it
        pal = self._sheet_pal
        sheet.hidden = False
        fade = 8
        for f in range(fade + 1):
            t = f / fade
            g = self._lerp_color(0x000000, SHEET_GRAY, t)
            for i in range(1, 14):
                pal[i] = g
            if not await self._frame():
                return False
        self.rail.x, self.rail.y = 0, 1
        self.rail.hidden = False
        self.laser_head.y = 2
        self.laser_head.hidden = False
        enter = 6
        for f in range(enter + 1):
            t = _ease_out(f / enter)
            self.laser_head.x = int(round(-8 + 9 * t))
            if not await self._frame():
                return False
        # The cut: one pass, the letters go dark behind the beam.
        self.beam.y = 7
        self.beam.hidden = False
        for step, x in enumerate(range(4, 61)):
            self.laser_head.x = x - 3
            self.beam.x = x
            self._beam_pal[1] = LASER_RED if step % 4 < 2 else LASER_DIM
            pal[2 + min((x - 4) * 12 // 56, 11)] = 0x000000
            if step % 7 == 0 and x < 58:
                self._launch_sparks(x, 14, 5)
            self._step_sparks()
            if not await self._frame():
                return False
        self.beam.hidden = True
        for f in range(7):
            self.laser_head.x = 58 + f * 2
            self._step_sparks()
            if not await self._frame():
                return False
        self.laser_head.hidden = True
        self.rail.hidden = True
        if not await self._hold(4):
            return False
        # The cut piece takes the brand: gray flips to safety yellow.
        flip = 8
        for f in range(flip + 1):
            t = f / flip
            pal[1] = self._lerp_color(SHEET_GRAY, PALETTE_COLORS[1], t)
            if not await self._frame():
                return False
        sheet.hidden = True
        self._show_logo()
        return True

    # -- the saw: a board rip (interstitial) and the saw-cut exit ------------

    async def _scene_sawmill(self):
        """The wood shop, on an otherwise empty panel: the blade spins up
        through the table, a board feeds through right to left, the cut
        piece pulls ahead as the kerf opens, sawdust flying."""
        self._hide_all()
        self._raise_actors()
        self.table.x, self.table.y = 8, 26
        self.table.hidden = False
        bx, by = 22, 14                    # blade tile; center (28, 20)
        for f in range(10):
            self._saw_pose(f, bx, by)
            if not await self._frame():
                return False
        x = 66.0
        lead = 0.0
        frame = 0
        while x + 24 + 22 > -12:
            x -= 1.2
            if x + 24 < 28:                # the seam has passed the blade
                lead += 0.8
            self.board[0].x = int(round(x - lead))
            self.board[0].y = 20
            self.board[0].hidden = False
            self.board[1].x = int(round(x + 24))
            self.board[1].y = 20
            self.board[1].hidden = False
            self._saw_pose(frame, bx, by)
            if frame % 5 == 0 and x < 34 and x + 46 > 22:
                self._launch_sparks(28, 19, 4, color=SAWDUST)
            self._step_sparks()
            frame += 1
            if not await self._frame():
                return False
        for tile in self.board:
            tile.hidden = True
        for f in range(8):                 # spin-down
            self._saw_pose(f, bx, by, rate=4)
            if not await self._frame():
                return False
        self._hide_all()
        return await self._hold(8)

    async def _sawcut_exit(self):
        """Any layout: the blade crosses the mark on its midline, the kerf
        opening behind it, and the freed halves fall apart off-panel."""
        top, bot, mid = self._half_tiles()
        self._raise_actors()
        self._hide_glyphs()
        top.x = top.y = bot.x = bot.y = 0
        top.hidden = bot.hidden = False
        blade_y = mid - 6
        for f in range(34):
            x = int(round(-14 + f * 2.5))
            self._saw_pose(f, x, blade_y)
            self.kerf.y = mid
            self.kerf.x = x - 64 + 7
            self.kerf.hidden = False
            if f % 6 == 0 and -6 < x < 58:
                self._launch_sparks(x + 6, mid, 4, color=SAWDUST)
            self._step_sparks()
            if not await self._frame():
                return False
        self._hide_saw()
        self.kerf.hidden = True
        sep = 12
        for f in range(sep + 1):
            t = _ease_in(f / sep)
            top.y = -int(round((mid + 2) * t))
            bot.y = int(round((34 - mid) * t))
            self._step_sparks()
            if not await self._frame():
                return False
        top.hidden = bot.hidden = True
        top.y = bot.y = 0
        self._hide_all()
        return True

    # -- the 3D printer: the mark rasters in, bottom-up ----------------------

    async def _printer_build(self):
        """The nozzle sweeps the gantry, laying the mark down one band per
        pass, bottom-up; fresh bands glow orange and cool to yellow two
        passes later. All band work is palette paints on a row partition."""
        self._hide_all()
        fx = self._fx("printrows")
        self._raise_actors()           # after the lazy fx, above it
        colors = [0x000000] * 7
        fx.paint(colors)
        fx.set_identity(0x000000, 0x000000)
        fx.tile.hidden = False
        y0, h = ink_rows(self._logo_slots)
        self.laser_head.hidden = False
        self.rail.hidden = False
        for band in range(6, -1, -1):
            band_top = y0 + band * h // 7
            head_y = max(band_top - 5, 0)
            self.laser_head.y = head_y
            self.rail.y = max(head_y - 1, 0)
            rightward = (6 - band) % 2 == 0
            for f in range(15):
                span = 2 + f * 4
                self.laser_head.x = span if rightward else 57 - span + 2
                if not await self._frame():
                    return False
            colors[band] = H_ORANGE
            if band < 6:
                colors[band + 1] = H_YELLOW
            if band < 5:
                colors[band + 2] = PALETTE_COLORS[1]
            fx.paint(colors)
        for f in range(6):
            self.laser_head.x = 60 + f * 2
            if not await self._frame():
                return False
        self.laser_head.hidden = True
        self.rail.hidden = True
        for cool in ((H_YELLOW, PALETTE_COLORS[1]),
                     (PALETTE_COLORS[1], PALETTE_COLORS[1])):
            colors[0], colors[1] = cool
            fx.paint(colors)
            if not await self._hold(4):
                return False
        fx.set_identity(PALETTE_COLORS[2], PALETTE_COLORS[3])
        if not await self._hold(2):
            return False
        fx.tile.hidden = True
        self._show_logo()
        return True

    # -- the MIG welder: the block's seam, bead by bead ----------------------

    async def _weld_build(self):
        """Block-layout build. The torch rides the plate's perimeter with
        a shimmering blue-white arc, laying a white-hot bead that cools
        to yellow behind it; when the loop closes, the interior floods
        yellow and the knockout letters appear."""
        self._set_layout("block")
        self._hide_all()
        fx = self._fx("weldseam")
        self._raise_actors()           # after the lazy fx, above it
        path = self._weld_path
        colors = [0x000000] * 17
        fx.paint(colors)
        fx.set_identity(0x000000, 0x000000)
        fx.tile.hidden = False
        n = len(path)
        for i in range(0, n + 1, 2):
            px, py = path[min(i, n - 1)]
            self.torch.x, self.torch.y = px, py - 5
            self.torch.hidden = False
            arc_on = (i // 2) % 2
            for j, tile in enumerate(self.arc):
                tile.x, tile.y = px - 1, py - 1
                tile.hidden = j != arc_on
            seg = min(i * 16 // n, 15)
            colors[seg] = HEAT_RAMP[4]
            if seg >= 1:
                colors[seg - 1] = HEAT_RAMP[3]
            for k in range(max(seg - 1, 0)):
                colors[k] = PALETTE_COLORS[1]
            fx.paint(colors)
            if i % 12 == 0:
                self._launch_sparks(px, py, 4)
            self._step_sparks()
            if not await self._frame():
                return False
        self.torch.hidden = True
        for tile in self.arc:
            tile.hidden = True
        # The loop closes: the interior floods yellow.
        flood = 10
        for f in range(flood + 1):
            t = f / flood
            colors[16] = self._lerp_color(0x000000, PALETTE_COLORS[1], t)
            for k in range(16):
                colors[k] = self._lerp_color(colors[k],
                                             PALETTE_COLORS[1], 0.4)
            fx.paint(colors)
            self._step_sparks()
            if not await self._frame():
                return False
        for k in range(17):
            colors[k] = PALETTE_COLORS[1]
        fx.paint(colors)
        fx.set_identity(PALETTE_COLORS[2], PALETTE_COLORS[3])
        if not await self._hold(2):
            return False
        fx.tile.hidden = True
        self._show_logo()
        return True

    # -- the potter's wheel (interstitial) -----------------------------------

    async def _scene_wheel(self):
        """The ceramics studio: the wheel rises spinning, the clay steps
        through its profiles — lump, cylinder, vase, pot — then the pot
        fires kiln-hot, cools, and the wheel sinks away."""
        self._hide_all()
        self._raise_actors()
        wx, wy = 23, 24
        rise = 8
        for f in range(rise + 1):
            t = _ease_out(f / rise)
            dy = int(round((1 - t) * 10))
            self._wheel_pose(f, wx, wy + dy)
            self.clay[0].x, self.clay[0].y = 26, wy - 4 + dy
            self.clay[0].hidden = False
            if not await self._frame():
                return False
        shapes = ((self.clay[0], wy - 4), (self.clay[1], wy - 6),
                  (self.clay[2], wy - 7), (self.clay[3], wy - 7))
        current = self.clay[0]
        frame = 0
        for tile, cy in shapes:
            current.hidden = True
            tile.x, tile.y = 26, cy
            tile.hidden = False
            current = tile
            for _ in range(18):
                self._wheel_pose(frame, wx, wy)
                frame += 1
                if not await self._frame():
                    return False
        # Kiln flash: the pot fires, then cools back.
        self.pot_hot.x, self.pot_hot.y = 26, wy - 7
        current.hidden = True
        self.pot_hot.hidden = False
        for _ in range(10):
            self._wheel_pose(frame, wx, wy)
            frame += 1
            if not await self._frame():
                return False
        self.pot_hot.hidden = True
        self.clay[3].hidden = False
        if not await self._hold(10):
            return False
        for f in range(9):
            t = _ease_in(f / 8)
            dy = int(round(t * 16))
            self._wheel_pose(frame + f, wx, wy + dy)
            self.clay[3].y = wy - 7 + dy
            if not await self._frame():
                return False
        self._hide_all()
        return await self._hold(8)

    # -- the sewing machine: a stitched underline ----------------------------

    async def _scene_stitch(self):
        """The textiles studio signs its work: the machine crosses under
        the mark, needle bobbing, leaving a dashed stitch rule behind."""
        self._set_layout("line")
        self._hide_all()
        self._raise_actors()
        if not await self._reveal_logo_via("Gradual Reveal"):
            return False
        if not await self._hold(6):
            return False
        mx = -18.0
        frame = 0
        while mx < 66:
            mx += 1.6
            needle_x = int(round(mx)) + 2
            self._sewer_pose(frame, int(round(mx)), 19)
            for i, dash in enumerate(self.dashes):
                if needle_x > 4 + 5 * i + 2:
                    dash.x, dash.y = 4 + 5 * i, 29
                    dash.hidden = False
            frame += 1
            if not await self._frame():
                return False
        self._hide_sewer()
        if not await self._dwell():
            return False
        if not await self._hide_logo_via("Horizontal Wipe"):
            return False
        return await self._hold(12)

    # -- the quench exit -----------------------------------------------------

    async def _quench_exit(self):
        """The mark heats through the ramp, then drops off the bottom edge
        into the slack tub — a hiss of pale spray where it goes under."""
        self._heat_tile()              # force the lazy tile into being
        self._raise_actors()           # so the spray rides above it
        if not await self._to_heat():
            return False
        if not await self._heat_breathe(8):
            return False
        tile = self._heat_tile()
        drop = 12
        for f in range(drop + 1):
            t = _ease_in(f / drop)
            tile.y = int(round(36 * t))
            if f == 7:
                self._launch_sparks(30, 30, 8, color=STEAM)
            self._step_sparks()
            if not await self._frame():
                return False
        tile.hidden = True
        tile.y = 0
        self._logo_mode = None
        for _ in range(6):
            self._step_sparks()
            if not await self._frame():
                return False
        self._hide_all()
        return True

    # -- the molten special: glow through the mark's strokes -----------------

    async def _scene_molten(self):
        """The panel goes black except the mark's strokes, through which
        banded molten light sweeps past — then the mark lights through
        its own holes, pixel-perfect."""
        self._hide_all()
        bg = self._molten_tile()       # created before the mask, so the
        mask = self._aperture_tile()   # mask stays above it
        bg.x = 0
        bg.hidden = False
        mask.hidden = False
        for y_from, y_to in ((-32, 0), (0, -32)):
            frames = 26
            for f in range(frames + 1):
                bg.y = int(round(y_from + (y_to - y_from) * f / frames))
                if not await self._frame():
                    return False
        bg.hidden = True
        self._show_logo()
        if not await self._hold(6):
            return False
        mask.hidden = True             # no visual change
        if not await self._pilot_flare():
            return False
        if not await self._hold(14):
            return False
        if not await self._hide_logo_via("Iris Snap"):
            return False
        return await self._hold(12)

    # -- scenes ---------------------------------------------------------------

    async def _scene_static(self):
        self._show_logo()
        if not await self._hold(30):
            return False
        if not await self._pilot_flare():
            return False
        return await self._hold(50)

    async def _scene_swarm(self):
        """The flock assembles the logo; a reverse flock deconstructs it."""
        if not await self._swarm_build():
            return False
        if not await self._dwell():
            return False
        if not await self._hold(6):
            return False
        if not await self._swarm_unbuild():
            return False
        return await self._hold(14)

    async def _scene_drip(self):
        """The logo rains in from the sky, wakes, then rains back out."""
        if not await self._drip_in("top"):
            return False
        if not await self._dwell():
            return False
        if not await self._hide_logo_via("Column Rain"):
            return False
        return await self._hold(12)

    async def _scene_wink(self):
        """A wall of yellow; everything that isn't the logo winks off."""
        if not await self._wink_in():
            return False
        if not await self._dwell():
            return False
        if not await self._hide_logo_via("CRT Collapse"):
            return False
        return await self._hold(12)

    async def _scene_heat(self):
        """The ignition act: the mark glows up out of the dark carrying the
        black-body gradation, breathes like a banked coal, then dies back
        down. Randomly fired from below or from above. All palette writes:
        zero per-frame pixel work."""
        self._hide_all()
        ramp = HEAT_RAMP if random.random() < 0.5 else tuple(reversed(HEAT_RAMP))
        self._paint_ramp((0x000000,) * len(ramp))
        self._set_core_palette(0x000000, 0x000000)
        self._heat_tile().hidden = False
        self._logo_mode = "heat"
        self._heat_ramp = ramp

        # Ignite: the strokes glow up first, the pilot wakes a beat later.
        ignite = 18
        for f in range(ignite + 1):
            t = f / ignite
            self._paint_ramp(tuple(
                self._lerp_color(0x000000, c, t * t) for c in ramp))
            et = max(0.0, (t - 0.35) / 0.65)
            self._set_core_palette(
                self._lerp_color(0x000000, PALETTE_COLORS[2], et),
                self._lerp_color(0x000000, PALETTE_COLORS[3], et))
            if not await self._frame():
                return False

        if not await self._heat_breathe(110, flare_at=(40, 84)):
            return False

        # Die down.
        fade = 20
        for f in range(fade + 1):
            t = f / fade
            self._paint_ramp(tuple(
                self._lerp_color(c, 0x000000, t) for c in ramp))
            self._set_core_palette(
                self._lerp_color(PALETTE_COLORS[2], 0x000000, t),
                self._lerp_color(PALETTE_COLORS[3], 0x000000, t))
            if not await self._frame():
                return False

        self._hide_all()
        self._set_core_palette(PALETTE_COLORS[2], PALETTE_COLORS[3])
        self._paint_ramp(HEAT_RAMP)
        return await self._hold(10)

    async def _scene_fx(self, fx_name, treatment, build_via, hide_via):
        """Standalone loop for a palette treatment: wipe the logo in, run
        the treatment, wipe it out."""
        if not await self._reveal_logo_via(build_via):
            return False
        if not await self._hold(8):
            return False
        if not await self._fx_treatment(fx_name, treatment):
            return False
        if not await self._hold(10):
            return False
        if not await self._hide_logo_via(hide_via):
            return False
        return await self._hold(12)

    async def _scene_temper(self):
        """The full Temper Library: every edition in sequence."""
        self._hide_all()
        self._show_logo()
        if not await self._hold(12):
            return False
        for edition in TEMPER_EDITIONS:
            if not await self._fx_treatment(
                    "diag", self._temper_make(edition)):
                return False
            if not await self._hold(6):
                return False
        if not await self._hide_logo_via("Pixel Dissolve"):
            return False
        return await self._hold(12)

    async def _scene_strike(self):
        """The signature vignette as its own loop: forge the emblem,
        admire it while heat rings out from the anvil, dissolve away."""
        if not await self._strike_build():
            return False
        if not await self._dwell():
            return False
        if not await self._fx_treatment(
                "wake", lambda fx: AnchorWake(fx, HEAT_RAMP)):
            return False
        if not await self._hold(8):
            return False
        if not await self._hide_logo_via("Glitch Bars"):
            return False
        return await self._hold(12)

    async def _scene_laser(self):
        """The laser cuts the block; heat haze shimmers over the fresh
        piece; the CRT switches off."""
        if not await self._laser_build():
            return False
        if not await self._dwell():
            return False
        if not await self._fx_treatment(
                "checker", lambda fx: InkShimmer(fx, HEAT_RAMP)):
            return False
        if not await self._hold(8):
            return False
        if not await self._hide_logo_via("CRT Collapse"):
            return False
        return await self._hold(12)

    async def _scene_print(self):
        """The printer rasters the mark in, it dwells, and wipes away."""
        self._set_layout("line")
        if not await self._printer_build():
            return False
        if not await self._dwell():
            return False
        if not await self._hide_logo_via("Diagonal Wipe"):
            return False
        return await self._hold(12)

    async def _scene_weld(self):
        """The torch welds the block's seam shut; the piece dwells hot."""
        if not await self._weld_build():
            return False
        if not await self._dwell():
            return False
        if not await self._hide_logo_via("Glitch Bars"):
            return False
        return await self._hold(12)

    async def _scene_sawcut(self):
        """The mark resolves in, then the table saw cuts it in half."""
        self._set_layout("line")
        if not await self._reveal_logo_via("Mosaic Resolve"):
            return False
        if not await self._dwell():
            return False
        if not await self._sawcut_exit():
            return False
        return await self._hold(12)

    async def _scene_quench(self):
        """The mark slides in, heats through the ramp, and is quenched."""
        if not await self._reveal_logo_via("Light Slit"):
            return False
        if not await self._dwell():
            return False
        if not await self._quench_exit():
            return False
        return await self._hold(12)

    async def _scene_unforge(self):
        """The emblem irises in, then the hammer takes it all back."""
        self._set_layout("emblem")
        if not await self._reveal_logo_via("Iris Snap"):
            return False
        if not await self._dwell():
            return False
        if not await self._unforge_exit():
            return False
        return await self._hold(12)

    async def _scene_layout(self, layout, build_via, fx_name, treatment,
                            hide_via):
        """Preview loop for one layout: wipe in, dwell, one representative
        treatment (anchored where it shows the layout's own anchor), wipe
        out."""
        self._set_layout(layout)
        if not await self._reveal_logo_via(build_via):
            return False
        if not await self._dwell():
            return False
        if not await self._fx_treatment(fx_name, treatment):
            return False
        if not await self._hold(8):
            return False
        if not await self._hide_logo_via(hide_via):
            return False
        return await self._hold(12)

    async def _scene_tour(self):
        """Four representative treatments back to back, for review."""
        for fx_name, treatment in (
                ("checker", lambda fx: InkShimmer(fx, HEAT_RAMP)),
                ("exposure", lambda fx: RimLight(fx, HEAT_RAMP,
                                                 highlight=H_WHITE,
                                                 sheltered=WORKLIGHT_SHADE)),
                ("regions", lambda fx: HeatmapDrift(fx, HEAT_RAMP)),
                ("wake", lambda fx: AnchorWake(fx, HEAT_RAMP))):
            self._hide_all()
            self._show_logo()
            if not await self._hold(8):
                return False
            if not await self._fx_treatment(fx_name, treatment):
                return False
            if not await self._hold(10):
                return False
        return True

    # -- the shuffle: scheduled variety, 24/7 --------------------------------

    async def _heat_dev_treatment(self):
        """The heat gradation as a composable dwell treatment: develop,
        breathe, settle back to flat."""
        if not await self._to_heat():
            return False
        if not await self._heat_breathe(40, flare_at=(16,)):
            return False
        return await self._to_flat()

    def _decks(self):
        """The scheduler's material, tagged by visual family. Anything
        sharing a family is 'similar' and never plays together; every
        tool act shares the ``vignette`` family so two shop vignettes
        never run back to back."""
        if getattr(self, "_deck_cache", None) is not None:
            return self._deck_cache
        builds = (
            ("swarm", "swarm", lambda: self._swarm_build()),
            ("heatswarm", "swarm", lambda: self._swarm_build(heat=True)),
            ("drip-down", "fall", lambda: self._drip_in("top")),
            ("drip-up", "fall", lambda: self._drip_in("bottom")),
            ("wink", "wall", lambda: self._wink_in()),
            ("iris-in", "radial", lambda: self._reveal_logo_via("Iris Snap")),
            ("slit-in", "sweep", lambda: self._reveal_logo_via("Light Slit")),
            ("mosaic-in", "texture",
             lambda: self._reveal_logo_via("Mosaic Resolve")),
            ("gradual-in", "sweep",
             lambda: self._reveal_logo_via("Gradual Reveal")),
            ("venetian-in", "bands",
             lambda: self._reveal_logo_via("Venetian Shutters")),
            ("scan-in", "bands", lambda: self._reveal_logo_via("Scan Fold")),
        )
        treats = (
            ("anneal", "sweep",
             lambda: self._fx_treatment(
                 "diag", lambda fx: VelvetSweep(fx, HEAT_RAMP))),
            ("strikewake", "radial",
             lambda: self._fx_treatment(
                 "wake", lambda fx: AnchorWake(fx, HEAT_RAMP))),
            ("heatbloom", "radial",
             lambda: self._fx_treatment(
                 "radial", lambda fx: HaloPulse(fx, HEAT_RAMP))),
            ("beacon", "radial",
             lambda: self._fx_treatment(
                 "angle", lambda fx: SonarSweep(fx, HEAT_RAMP))),
            ("sparkrain", "fall",
             lambda: self._fx_treatment(
                 "rain", lambda fx: CipherRain(fx, HEAT_RAMP))),
            ("shimmer", "texture",
             lambda: self._fx_treatment(
                 "checker", lambda fx: InkShimmer(fx, HEAT_RAMP))),
            ("caseharden", "texture",
             lambda: self._fx_treatment(
                 "topo", lambda fx: StrokeAnatomy(fx, HEAT_RAMP))),
            ("hotspots", "texture",
             lambda: self._fx_treatment(
                 "regions", lambda fx: HeatmapDrift(fx, HEAT_RAMP))),
            ("temper", "texture",
             lambda: self._fx_treatment("diag", self._temper_make())),
            ("toolpath", "route",
             lambda: self._fx_treatment("route", self._toolpath_make())),
            ("jobqueue", "route",
             lambda: self._fx_treatment("route", self._jobqueue_make())),
            ("worklight", "sweep",
             lambda: self._fx_treatment(
                 "exposure", lambda fx: RimLight(fx, HEAT_RAMP,
                                                 highlight=H_WHITE,
                                                 sheltered=WORKLIGHT_SHADE))),
            ("heatdev", "heat", self._heat_dev_treatment),
        )
        exits = (
            ("quench", "fall", self._quench_exit, False),
            ("unswarm", "swarm", self._swarm_unbuild, False),
            ("crt-out", "collapse",
             lambda: self._hide_logo_via("CRT Collapse"), False),
            ("dissolve-out", "texture",
             lambda: self._hide_logo_via("Pixel Dissolve"), False),
            ("glitch-out", "bands",
             lambda: self._hide_logo_via("Glitch Bars"), False),
            ("rain-out", "fall",
             lambda: self._hide_logo_via("Column Rain"), False),
            ("diag-out", "sweep",
             lambda: self._hide_logo_via("Diagonal Wipe"), False),
            ("wipe-out", "sweep",
             lambda: self._hide_logo_via("Horizontal Wipe"), False),
        )
        self._deck_cache = (builds, treats, exits)
        return self._deck_cache

    @staticmethod
    def _deck_for_layout(deck, l_name):
        """Drop the acts whose choreography doesn't fit this layout."""
        out = []
        for item in deck:
            allowed = ACT_LAYOUTS.get(item[0])
            if allowed is None or l_name in allowed:
                out.append(item)
        return tuple(out)

    def _sched_pick(self, deck, deck_key, avoid, force=None):
        """The library's weighted-age, family-aware picker: least-recently
        seen leads, no family in ``avoid`` repeats, and ``force`` names
        the boot opener with the same age bookkeeping."""
        sched = getattr(self, "_sched", None)
        if sched is None:
            sched = self._sched = ActScheduler()
        return sched.pick(deck, deck_key, avoid, force)

    async def _scene_shuffle(self):
        """The anti-boredom mode. Acts strictly alternate: an abstract
        logo act (build / dwell treatment / exit, family-scheduled), then
        a shop activity (a tool vignette), then abstract again. The very
        first act after power-up is always the strike — the sign forges
        itself when the shop wakes up — and the alternation runs from
        there."""
        first = not getattr(self, "_shuffle_opened", False)
        self._shuffle_opened = True
        activity = first or getattr(self, "_next_turn", "") == "activity"
        self._next_turn = "abstract" if activity else "activity"
        if activity:
            return await self._activity_act(force="strike" if first else None)
        return await self._abstract_act()

    async def _activity_act(self, force=None):
        """One shop activity, drawn with the same weighted-age scheduler
        so the tools rotate: each activity carries its own family and
        the same tool never works two activity turns in a row."""
        deck = (
            ("strike", "anvil", self._scene_strike),
            ("unforge", "anvil", self._scene_unforge),
            ("laser", "laser", self._scene_laser),
            ("weld", "torch", self._scene_weld),
            ("print", "printer", self._scene_print),
            ("sawcut", "saw", self._scene_sawcut),
            ("sawmill", "saw", self._scene_sawmill),
            ("wheel", "clay", self._scene_wheel),
            ("stitch", "sew", self._scene_stitch),
        )
        avoid = {getattr(self, "_prev_activity", None)} - {None}
        _name, fam, act = self._sched_pick(deck, "act", avoid, force)
        self._prev_activity = fam
        return await act()

    async def _abstract_act(self):
        """One abstract logo act: rotate the layout, then build, dwell,
        and exit with the family-aware scheduler. The ignition and
        molten specials live here too, kept rare."""
        prev = getattr(self, "_prev_families", set())
        lay_deck = tuple((name, name) for name in LAYOUTS)
        l_name, _fam = self._sched_pick(lay_deck, "layout",
                                        {self._layout_name})
        self._set_layout(l_name)

        # Special self-contained acts, kept rare and never back to back.
        if (not getattr(self, "_last_was_special", False)
                and random.random() < 0.14):
            self._last_was_special = True
            special = ((self._scene_heat, "heat"),
                       (self._scene_molten, "aperture"))
            scene, fam = special[random.randrange(len(special))]
            self._prev_families = {fam}
            return await scene()
        self._last_was_special = False

        builds, treats, exits = self._decks()
        builds = self._deck_for_layout(builds, l_name)
        treats = self._deck_for_layout(treats, l_name)
        used = set(prev)

        b_name, b_fam, build = self._sched_pick(builds, "b", used)
        used.add(b_fam)
        if not await build():
            return False

        # A heat arrival (heat swarm) breathes and settles first.
        if self._logo_mode == "heat":
            if not await self._heat_breathe(30, flare_at=(12,)):
                return False
            if not await self._to_flat():
                return False
            used.add("heat")

        skeleton = random.random()
        if skeleton < 0.15:
            # quick act: just a short plain dwell
            if not await self._hold(random.randint(10, 18)):
                return False
            if not await self._pilot_flare():
                return False
            if not await self._hold(random.randint(4, 10)):
                return False
        else:
            count = 2 if skeleton > 0.75 else 1
            for _ in range(count):
                t_name, t_fam, treat = self._sched_pick(treats, "t", used)
                used.add(t_fam)
                if not await treat():
                    return False
                if count == 2 and not await self._hold(6):
                    return False

        e_name, e_fam, out, needs_flat = self._sched_pick(exits, "e", used)
        used.add(e_fam)
        if needs_flat and not await self._to_flat():
            return False
        if not await out():
            return False
        self._prev_families = used - prev if used - prev else used
        return await self._hold(8)

    # -- app entry -----------------------------------------------------------

    async def setup(self):
        if hasattr(self.display, "create_window"):
            await self.display.create_window("The Forge - ScrollKit")
        self._build_sprites()

        scenes = {
            "static": self._scene_static,
            "swarm": self._scene_swarm,
            "drip": self._scene_drip,
            "wink": self._scene_wink,
            "heat": self._scene_heat,
            "temper": self._scene_temper,
            "strike": self._scene_strike,
            "laser": self._scene_laser,
            "sawmill": self._scene_sawmill,
            "sawcut": self._scene_sawcut,
            "print": self._scene_print,
            "weld": self._scene_weld,
            "wheel": self._scene_wheel,
            "stitch": self._scene_stitch,
            "quench": self._scene_quench,
            "unforge": self._scene_unforge,
            "molten": self._scene_molten,
            "shuffle": self._scene_shuffle,
            "anneal": lambda: self._scene_fx(
                "diag", lambda fx: VelvetSweep(fx, HEAT_RAMP),
                "Gradual Reveal", "Diagonal Wipe"),
            "strikewake": lambda: self._scene_fx(
                "wake", lambda fx: AnchorWake(fx, HEAT_RAMP),
                "Iris Snap", "Horizontal Wipe"),
            "heatbloom": lambda: self._scene_fx(
                "radial", lambda fx: HaloPulse(fx, HEAT_RAMP),
                "Iris Snap", "Pixel Dissolve"),
            "beacon": lambda: self._scene_fx(
                "angle", lambda fx: SonarSweep(fx, HEAT_RAMP),
                "Light Slit", "CRT Collapse"),
            "sparkrain": lambda: self._scene_fx(
                "rain", lambda fx: CipherRain(fx, HEAT_RAMP),
                "Column Rain", "Column Rain"),
            "shimmer": lambda: self._scene_fx(
                "checker", lambda fx: InkShimmer(fx, HEAT_RAMP),
                "Gradual Reveal", "Pixel Dissolve"),
            "caseharden": lambda: self._scene_fx(
                "topo", lambda fx: StrokeAnatomy(fx, HEAT_RAMP),
                "Scan Fold", "Pixel Dissolve"),
            "hotspots": lambda: self._scene_fx(
                "regions", lambda fx: HeatmapDrift(fx, HEAT_RAMP),
                "Mosaic Resolve", "Glitch Bars"),
            "toolpath": lambda: self._scene_fx(
                "route", self._toolpath_make(), "Mosaic Resolve",
                "Glitch Bars"),
            "jobqueue": lambda: self._scene_fx(
                "route", self._jobqueue_make(), "Mosaic Resolve",
                "Glitch Bars"),
            "worklight": lambda: self._scene_fx(
                "exposure", lambda fx: RimLight(fx, HEAT_RAMP,
                                                highlight=H_WHITE,
                                                sheltered=WORKLIGHT_SHADE),
                "Venetian Shutters", "Diagonal Wipe"),
            "line": lambda: self._scene_layout(
                "line", "Light Slit", "wake",
                lambda fx: AnchorWake(fx, HEAT_RAMP), "Diagonal Wipe"),
            "block": lambda: self._scene_layout(
                "block", "Gradual Reveal", "checker",
                lambda fx: InkShimmer(fx, HEAT_RAMP), "CRT Collapse"),
            "rows": lambda: self._scene_layout(
                "rows", "Venetian Shutters", "rain",
                lambda fx: CipherRain(fx, HEAT_RAMP), "Diagonal Wipe"),
            "emblem": lambda: self._scene_layout(
                "emblem", "Iris Snap", "radial",
                lambda fx: HaloPulse(fx, HEAT_RAMP), "Pixel Dissolve"),
            "badge": lambda: self._scene_layout(
                "badge", "Light Slit", "wake",
                lambda fx: AnchorWake(fx, HEAT_RAMP), "Glitch Bars"),
            "tour": self._scene_tour,
        }
        scene = scenes[self.version]
        while self.running:
            if await scene() is False:
                return self._request_shutdown()


if __name__ == "__main__":
    version = sys.argv[1] if len(sys.argv) > 1 else "static"
    if version not in ForgeLogoApp.VERSIONS:
        print("usage: forge_logo.py [%s]" % "|".join(ForgeLogoApp.VERSIONS))
        sys.exit(1)
    asyncio.run(ForgeLogoApp(version).run())
