# The Forge LED Logo

Dynamic logo + maker-vignette animations for a 64x32 RGB LED matrix, for
**The Forge** — the community makerspace in Greensboro, NC
(forgegreensboro.org, "Like a gym for makers"). Sibling of
`../darkowl-led-logo`, which is the architectural reference; ScrollKit is
the library both apps are built on.

## The brief

Two kinds of content, endlessly shuffled:

1. **The dynamic logo** — the FORGE wordmark in many variations: five
   layouts, dozens of build/dwell/exit acts, so the viewer can't remember
   them all.
2. **Maker vignettes** — little animations of things being made, one per
   shop: hammer-on-anvil (the building was literally a blacksmith shop),
   laser cutter with a spark shower, table saw, 3D printer, MIG welder,
   potter's wheel, sewing machine. Legibility at 64x32 is the bar; most
   vignettes double as logo builds or exits.

## The one design rule

The mark stays recognizably **safety-yellow (#F7EE21) on black** at all
times. Treatments roam heat tones (the black-body HEAT_RAMP, steel temper
editions) and every treatment starts and ends at flat brand yellow. Cool
hues appear only diegetically inside vignettes (laser red, welding-arc
blue-white) and never as a logo state. **No strobing** — flashes are
single localized events (a hammer impact, a ≤2-frame arc shimmer), never
panel-wide on/off cycles: an unattended strobing sign reads as hardware
failure.

## Architecture

- `code.py` — device entry point; runs `ForgeLogoApp("shuffle")` 24/7.
- `forge_logo.py` — the whole app, one `ScrollKitApp` subclass. LAYOUTS
  registry (line/block/rows/emblem/badge), `_build_sprites()` builds every
  tile once at startup, animation is prebuilt-TileGrid moves + palette
  writes (the `_fx`/PalettePartition framework), `_decks()` + ActScheduler
  drive the shuffle. Scenes are self-driving coroutines returning
  True/False; False propagates up and shuts down.
- `glyphs.py` — ASCII-rows pixel art (letters CAPS20/CAPS13/CAPS8, anvil,
  hammer poses, tool sprites) + the palette + `panel_color()` gamma.
- `preview.py` — headless PNG/GIF/MP4 renders to `previews/` via
  ScrollKit's recorder. `sprite_check.py` — big LED-dot sprite sheet.
- `tools/` — layout mockups + the base64 review page builder.
- `scripts/deploy.sh` — rsync to a USB-mounted CIRCUITPY (MatrixPortal S3).

## Hardware + constraints (inherited from darkowl, all verified there)

- Adafruit MatrixPortal S3, CircuitPython 10.x, 64x32 HUB75 panel,
  `bit_depth=6` (dark accents crush to black at RGB444 after gamma).
- 50ms/frame budget at 20fps. Cheap: moving prebuilt TileGrids, palette
  writes. Deadly: per-frame Python pixel loops (~7µs/pixel) and per-frame
  allocation. Swarm ≤ 16 birds; ≤ ~10 live particle tiles.
- Every design color is gamma-encoded once at import
  (`glyphs.panel_color`, `PANEL_GAMMA=2.2`); ScrollKit treatment defaults
  are design-space and must be overridden at every call site.
  `FORGE_PANEL_GAMMA=1 python3 ...` previews the hardware mapping on
  desktop.
- CircuitPython compat: no `typing`/`os.path` at runtime (desktop-only
  guard at the top of forge_logo.py), no extended/step slices, no
  `random.shuffle`, `time.monotonic` for clocks. Everything must run
  unchanged on the board.

## Workflow

- Verify visuals from FULL-SIZE extracted frames, never downscaled
  contact sheets (the LED dot grid aliases into moiré). Pillow collapses
  identical consecutive GIF frames, so frame index ≠ wall-clock.
- Use ScrollKit's built-in recorder only (`display.save_gif/save_video/
  screenshot`).
- Adding a scene: build it from prebuilt tiles + palette writes, tag its
  visual family, add to `_decks()` and (optionally) `VERSIONS` + the
  `setup()` scenes dict + `preview.py` PLANS. Then: headless smoke test →
  full-size frame spot-check → `python3 preview.py <version>` → review
  page → commit.

## Layouts, anchors, and the vignette contract

- Five layouts: `line` (FORGE at CAPS20), `block` (the brand knockout —
  one generated glyph, lit field, unlit letterforms), `rows` (THE over
  FORGE), `emblem` (word standing over the stencil anvil — the strike
  vignette builds this one), `badge` (big anvil + stacked words).
- **Logo glyphs use only palette slots 1-3** (yellow/orange/white); the
  swarm color map, heat-gradient tile, and partitions all assume it.
  That's why the layout anvils are yellow stencils; the steel anvil
  belongs to the strike vignette. Material slots 9-11 are for actors and
  are never recolored by effects (vignettes may lerp them, e.g. the
  anvil transmute, but must restore them).
- The anchor is two-tier: the anvil's working face in emblem/badge, the
  O's ember-core pilot light everywhere else (`anchor_point` in
  LAYOUTS). The pilot flare (`_pilot_flare`) is the blink equivalent.
- `ACT_LAYOUTS` gates route treatments off the one-glyph block layout;
  the tool vignettes set their own layouts internally.
- The shuffle strictly ALTERNATES abstract logo acts with shop-activity
  acts (user direction, 2026-07-17): `_scene_shuffle` toggles between
  `_abstract_act` (family-scheduled build/treat/exit + rare specials)
  and `_activity_act` (its own weighted deck of the tool vignettes, one
  family per tool so the same tool never works twice running).
- **Vignettes must call `_raise_actors()` after any lazy layer they use
  is created** (fx partitions, the laser sheet, half tiles, heat tiles
  are added above whatever exists — the actors need re-raising or they
  render behind the scenery; cost one re-stack per scene start).
- The spark pool: ten 1-LED tiles on prebuilt ballistic arc tables, one
  shared 3-color palette; `_launch_sparks(x, y, n, color=)` +
  `_step_sparks()` every frame. Used for hammer sparks, laser plume,
  sawdust, weld spatter, quench steam.

## State (2026-07-17)

v1 complete on the simulator: 36 versions (see `VERSIONS`), all previews
rendered and frame-checked, shuffle verified over an 800-frame run.
Review page: `tools/build_review_page.py` → `theforge-led-review.html`.
Review artifact: https://claude.ai/code/artifact/73a9c7bc-cf3a-4325-b8db-f53115e39141
Perf: 75s shuffle under `SCROLLKIT_HW_SIM=1` — median modeled frame
15.3ms (65fps) against the 50ms budget, zero warnings, worst one-time
scene-start frame 57.9ms (under the 100ms transient ceiling).
`scripts/deploy.sh --dry-run` verified against a live CIRCUITPY mount.
**Careful: the box usually plugged into this Mac is the themeparkwaits
production unit — check `code.py` on the drive before any real deploy.**
Not yet done: real deploy to The Forge's own MatrixPortal S3, `showcase`
curated show, grindoff/solder/kiln vignettes (v1.1 candidates).
