#!/usr/bin/env python3
"""Headless previews of The Forge logo app, written to previews/:
a PNG of the static logo, GIFs of the short animations, and MP4s of the
long ones (swarm, shuffle).

The app is self-driving (setup() runs the show), so this uses the same
capture pattern as the library's demos/render_gifs.py: run setup() as a
cancellable task and stop once enough frames are recorded.

    python3 preview.py            # everything
    python3 preview.py strike     # just the named version(s)
"""

import asyncio
import os
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

from forge_logo import ForgeLogoApp  # noqa: E402  (also wires up scrollkit path)

OUT = os.path.join(_HERE, "previews")
os.makedirs(OUT, exist_ok=True)

# max recorded frames per version (capture runs at the app's ~20 fps clock);
# and the output container: short loops read fine as GIFs, the long swarm /
# shuffle runs go to MP4 (needs ffmpeg on PATH).
PLANS = {
    "static":     {"frames": 12,   "kind": "png"},
    "line":       {"frames": 260,  "kind": "gif"},
    "block":      {"frames": 240,  "kind": "gif"},
    "rows":       {"frames": 260,  "kind": "gif"},
    "emblem":     {"frames": 260,  "kind": "gif"},
    "badge":      {"frames": 260,  "kind": "gif"},
    "heat":       {"frames": 170,  "kind": "gif"},
    "temper":     {"frames": 460,  "kind": "gif"},
    "anneal":     {"frames": 185,  "kind": "gif"},
    "strikewake": {"frames": 165,  "kind": "gif"},
    "heatbloom":  {"frames": 200,  "kind": "gif"},
    "beacon":     {"frames": 185,  "kind": "gif"},
    "sparkrain":  {"frames": 270,  "kind": "gif"},
    "shimmer":    {"frames": 135,  "kind": "gif"},
    "caseharden": {"frames": 180,  "kind": "gif"},
    "hotspots":   {"frames": 140,  "kind": "gif"},
    "toolpath":   {"frames": 185,  "kind": "gif"},
    "jobqueue":   {"frames": 195,  "kind": "gif"},
    "worklight":  {"frames": 120,  "kind": "gif"},
    "swarm":      {"frames": 580,  "kind": "mp4"},
    "drip":       {"frames": 140,  "kind": "gif"},
    "wink":       {"frames": 110,  "kind": "gif"},
    "strike":     {"frames": 260,  "kind": "gif"},
    "laser":      {"frames": 230,  "kind": "gif"},
    "sawmill":    {"frames": 130,  "kind": "gif"},
    "sawcut":     {"frames": 160,  "kind": "gif"},
    "print":      {"frames": 230,  "kind": "gif"},
    "weld":       {"frames": 210,  "kind": "gif"},
    "wheel":      {"frames": 135,  "kind": "gif"},
    "stitch":     {"frames": 200,  "kind": "gif"},
    "quench":     {"frames": 150,  "kind": "gif"},
    "unforge":    {"frames": 220,  "kind": "gif"},
    "molten":     {"frames": 180,  "kind": "gif"},
    "tour":       {"frames": 700,  "kind": "mp4"},
    "shuffle":    {"frames": 800,  "kind": "mp4"},
}
PITCH = 4.0  # crisper LEDs in the encoded output; logical grid stays 64x32


async def _capture(app, max_frames):
    """Run the app's self-driving setup() until max_frames are recorded."""
    await app._initialize_display()
    app.display.start_recording()
    app.running = True
    task = asyncio.create_task(app.setup())
    try:
        while not task.done() and len(app.display._recording or []) < max_frames:
            await asyncio.sleep(0.01)
    finally:
        app.running = False
        if not task.done():
            task.cancel()
            try:
                await task
            except BaseException:  # noqa: BLE001 — cancellation/teardown
                pass
        try:
            await app.cleanup()
        except Exception:
            pass


def render(version):
    plan = PLANS[version]
    app = ForgeLogoApp(version, pitch=PITCH)
    asyncio.run(_capture(app, plan["frames"]))
    if plan["kind"] == "png":
        path = app.display.screenshot(os.path.join(OUT, "static.png"))
    elif plan["kind"] == "mp4":
        # fps=20 matches the app's capture clock, so playback is true-speed.
        path = app.display.save_video(os.path.join(OUT, "%s.mp4" % version),
                                      fps=20, crf=22, target_width=480)
    else:
        path = app.display.save_gif(os.path.join(OUT, "%s.gif" % version),
                                    frame_step=2, target_width=480,
                                    max_colors=64)
    print("wrote", path)


if __name__ == "__main__":
    for version in (sys.argv[1:] or list(PLANS)):
        render(version)
