#!/usr/bin/env python3
"""Regenerate theforge-led-review.html with every animation embedded."""

import base64
import io
import pathlib

from PIL import Image, ImageSequence

PREV = pathlib.Path(__file__).resolve().parent.parent / "previews"
# The published artifact lives at:
#   https://claude.ai/code/artifact/73a9c7bc-cf3a-4325-b8db-f53115e39141
# To update it from a NEW session: rebuild this file, then publish with the
# Artifact tool passing that URL as `url` (otherwise a new URL is minted).
OUT = pathlib.Path(__file__).resolve().parent / "theforge-led-review.html"

MIME = {".png": "image/png", ".gif": "image/gif", ".mp4": "video/mp4"}


def _slim_gif(path, max_bytes=260_000):
    """Recompress a large GIF for embedding: 340px wide, every 2nd frame,
    48 colors — and a harder second pass (300px, every 3rd frame, 32
    colors) if that still busts the budget. Repo previews stay full
    quality; only the page embed slims."""
    raw = path.read_bytes()
    if len(raw) <= max_bytes:
        return raw
    for step, width, colors in ((2, 340, 48), (3, 300, 32)):
        im = Image.open(io.BytesIO(raw))
        frames, durations = [], []
        for i, fr in enumerate(ImageSequence.Iterator(im)):
            if i % step:
                continue
            f = fr.convert("RGB")
            f = f.resize((width, int(f.height * width / f.width)))
            frames.append(f.quantize(colors=colors))
            durations.append(fr.info.get("duration", 100) * step)
        buf = io.BytesIO()
        frames[0].save(buf, format="GIF", save_all=True,
                       append_images=frames[1:], duration=durations,
                       loop=0, optimize=True)
        if buf.tell() <= max_bytes:
            break
    return buf.getvalue()


def uri(name):
    p = PREV / name
    data = _slim_gif(p) if p.suffix == ".gif" else p.read_bytes()
    return "data:%s;base64,%s" % (MIME[p.suffix],
                                  base64.b64encode(data).decode())


def img(name, alt):
    return '<img src="%s" alt="%s" />' % (uri(name), alt)


def vid(name):
    return ('<video src="%s" autoplay loop muted playsinline '
            'aria-label="LED panel animation"></video>' % uri(name))


def fig(name, alt, left, right, first=False):
    style = "" if first else ' style="margin-top:1rem"'
    body = vid(name) if name.endswith(".mp4") else img(name, alt)
    return ('<figure%s>%s<figcaption><span>%s</span>'
            '<span class="ok">%s</span></figcaption></figure>'
            % (style, body, left, right))


HTML = """<title>The Forge LED Logo — Concept Review</title>
<style>
  :root {
    --ground: #0c0b06;
    --panel: #000000;
    --ink: #d9d4c0;
    --muted: #8f8a72;
    --brand: #f7ee21;
    --hot: #e86010;
    --line: #2a2712;
    --mono: ui-monospace, "SF Mono", SFMono-Regular, Menlo, monospace;
  }
  html { background: var(--ground); }
  body {
    font: 16px/1.6 system-ui, -apple-system, sans-serif;
    color: var(--ink);
    background: var(--ground);
    margin: 0;
    padding: 3rem 1.25rem 4rem;
  }
  main { max-width: 860px; margin: 0 auto; }
  .eyebrow {
    font-family: var(--mono);
    font-size: 0.75rem;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: var(--muted);
    margin: 0 0 0.75rem;
  }
  h1 {
    font-family: var(--mono);
    font-size: clamp(1.5rem, 4vw, 2.1rem);
    line-height: 1.2;
    color: var(--brand);
    margin: 0 0 0.5rem;
    text-wrap: balance;
  }
  .lede { color: var(--muted); max-width: 60ch; margin: 0 0 2.5rem; }
  .pair-label {
    font-family: var(--mono);
    font-size: 0.72rem;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    color: var(--hot);
    border-top: 1px solid var(--line);
    padding-top: 2rem;
    margin: 3rem 0 0.35rem;
  }
  section { margin: 0 0 2.75rem; }
  h2 {
    font-family: var(--mono);
    font-size: 1.05rem;
    letter-spacing: 0.02em;
    color: var(--ink);
    margin: 1.25rem 0 0.25rem;
  }
  .desc { color: var(--muted); max-width: 62ch; margin: 0 0 1.1rem; }
  figure {
    margin: 0;
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: clamp(0.75rem, 3vw, 1.5rem);
  }
  figure img, figure video { display: block; width: 100%; height: auto; }
  figcaption {
    font-family: var(--mono);
    font-size: 0.72rem;
    letter-spacing: 0.06em;
    color: var(--muted);
    display: flex;
    justify-content: space-between;
    gap: 1rem;
    flex-wrap: wrap;
    padding-top: 0.75rem;
  }
  figcaption .ok { color: var(--brand); }
  pre {
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 1rem 1.25rem;
    overflow-x: auto;
    font-family: var(--mono);
    font-size: 0.82rem;
    line-height: 1.7;
    color: var(--ink);
  }
  pre .c { color: var(--muted); }
  ul { padding-left: 1.2rem; color: var(--muted); max-width: 62ch; }
  li { margin-bottom: 0.4rem; }
  li strong { color: var(--ink); font-weight: 600; }
  code { font-family: var(--mono); font-size: 0.9em; }
</style>
<main>
  <p class="eyebrow">ScrollKit &middot; 64&times;32 RGB matrix &middot; MatrixPortal S3</p>
  <h1>The Forge LED logo &mdash; the mark, the shops, the shuffle</h1>
  <p class="lede">FORGE in the brand&rsquo;s safety yellow, five layouts deep, built and
  dismantled by the shops themselves: the hammer forges it on the anvil, the laser cuts
  it out of plate, the printer rasters it, the torch welds it shut, the saw cuts it in
  half. Everything below runs unchanged on the panel &mdash; prebuilt sprites and
  palette writes, ~20&nbsp;fps, no strobes, always recognizably yellow-on-black.</p>

  <section>
    <h2>Static <span style="color:var(--muted);font-weight:400">&mdash; the composition</span></h2>
    <p class="desc">The hero line: heavy condensed caps, 3px strokes, with the
    <em>pilot light</em> &mdash; a small ember core in the O&rsquo;s counter that
    breathes during dwells and pops white-hot on the mark&rsquo;s micro-events. The
    forge is always lit.</p>
    __STATIC__
  </section>

  <p class="pair-label">The five layouts</p>
  <section>
    <p class="desc">Shuffle draws a layout for every act with a weighted-age scheduler,
    never the same twice running. The anchored effects re-center on each layout&rsquo;s
    own anchor &mdash; the anvil where an anvil is on screen, the pilot-light O
    everywhere else.</p>
    __LINE__
    __BLOCK__
    __ROWS__
    __EMBLEM__
    __BADGE__
  </section>

  <p class="pair-label">The signature &middot; strike</p>
  <section>
    <h2>Hammer and anvil forge the wordmark</h2>
    <p class="desc">The building was a blacksmith shop; the sign remembers. The steel
    anvil drops in and lands in a spark puff; four hammer strikes stamp the letters
    white-hot &mdash; F, O, E, then R and G together on the finale &mdash; each clang
    throwing a ballistic spark shower off the working face. The forged letters cool
    through pale gold to brand yellow, and the anvil takes the brand too. This is the
    boot opener: the sign forges itself when the shop wakes up.</p>
    __STRIKE__
    <h2>Unforge (the exit twin)</h2>
    <p class="desc">The hammer returns and takes it all back &mdash; each strike bursts
    letters into sparks &mdash; then the anvil reverts to steel and sinks away.</p>
    __UNFORGE__
  </section>

  <p class="pair-label">The laser department</p>
  <section>
    <h2>Laser-cut from steel plate</h2>
    <p class="desc">A gray plate fades in; the carriage rides the gantry with a red
    beam slicing down through it, a spark plume rising off the cut point, the
    letterforms going dark behind it column by column. When the cut finishes, the
    piece flips safety yellow &mdash; the plate <em>is</em> the brand&rsquo;s knockout
    block. The cut itself is a palette sweep over pre-banded pixels: zero per-frame
    pixel work.</p>
    __LASER__
  </section>

  <p class="pair-label">The wood shop</p>
  <section>
    <h2>Sawmill (interstitial)</h2>
    <p class="desc">Between acts, sometimes the shop just works: the blade spins up
    through the table, a board feeds through right to left, and the cut piece pulls
    ahead as the kerf opens, sawdust flying.</p>
    __SAWMILL__
    <h2>Saw-cut (exit)</h2>
    <p class="desc">And sometimes the saw gets the sign: the blade crosses the mark on
    its midline, the kerf opening behind it, and the freed halves fall apart
    off-panel.</p>
    __SAWCUT__
  </section>

  <p class="pair-label">The 3D printing lab</p>
  <section>
    <h2>Printed, layer by layer</h2>
    <p class="desc">The nozzle rasters the gantry, laying the mark down one band per
    pass, bottom-up. Fresh layers glow extrusion-orange and cool to yellow two passes
    later.</p>
    __PRINT__
  </section>

  <p class="pair-label">The metal shop</p>
  <section>
    <h2>Weld the seam</h2>
    <p class="desc">The MIG torch rides the block&rsquo;s perimeter with a shimmering
    blue-white arc &mdash; the one cool color in the whole show, diegetic and
    localized &mdash; laying a white-hot bead that cools to yellow behind it. When the
    loop closes, the interior floods yellow and the knockout letters appear.</p>
    __WELD__
    <h2>Quench (exit)</h2>
    <p class="desc">The mark heats through the black-body ramp, then drops off the
    bottom edge into the slack tub with a hiss of pale spray.</p>
    __QUENCH__
  </section>

  <p class="pair-label">Ceramics &amp; textiles</p>
  <section>
    <h2>The potter&rsquo;s wheel (interstitial)</h2>
    <p class="desc">The wheel rises spinning; the clay steps through its profiles
    &mdash; lump, cylinder, vase, pot &mdash; then fires kiln-hot, cools, and the
    wheel sinks away.</p>
    __WHEEL__
    <h2>Stitch</h2>
    <p class="desc">The sewing machine crosses under the word, needle bobbing, and
    leaves a dashed stitch rule behind &mdash; the textiles studio signing the
    mark.</p>
    __STITCH__
  </section>

  <p class="pair-label">Heat &amp; color</p>
  <section>
    <h2>Ignition</h2>
    <p class="desc">The mark glows up out of the dark carrying a five-stop black-body
    gradation &mdash; dull ember red through white-hot &mdash; breathes like a banked
    coal, and dies back down. Cooling metal passes <em>through</em> brand yellow, so
    every heat beat settles onto the flat mark. All palette writes.</p>
    __HEAT__
    <h2>Molten (special)</h2>
    <p class="desc">The panel goes black except the mark&rsquo;s strokes, through
    which banded molten light sweeps past &mdash; then the mark lights through its own
    holes, pixel-perfect.</p>
    __MOLTEN__
    <h2>The Temper Library</h2>
    <p class="desc">Curated editions of the mark straight off tempering steel &mdash;
    safety, straw, molten, brass, white heat, banked coals &mdash; each dwelling and
    returning to canonical yellow. (The purple/blue end of real temper colors is
    deliberately excluded: it loses the yellow heart.)</p>
    __TEMPER__
  </section>

  <p class="pair-label">The treatment deck</p>
  <section>
    <h2>Eleven palette treatments, re-themed for the forge</h2>
    <p class="desc">The library&rsquo;s partition treatments with the heat ramp:
    anneal (a hot sheen sweeps the mark), strikewake (heat rings out from the anchor),
    heatbloom, beacon, sparkrain, shimmer (heat haze), caseharden (edges cool dark
    while cores glow &mdash; literally how steel cools), hotspots, toolpath and
    jobqueue (CNC packets crawl the actual letterform strokes), and worklight (a shop
    light rakes the strokes). A sampler:</p>
    __ANNEAL__
    __STRIKEWAKE__
    __CASEHARDEN__
    __TOOLPATH__
    __WORKLIGHT__
    __SHIMMER__
  </section>

  <p class="pair-label">Splash builds</p>
  <section>
    <h2>Spark swarm, drip, wink</h2>
    <p class="desc">A 16-bird flock in spark yellow assembles the mark pixel by pixel
    (and a reverse flock can carry it away); the mark can rain in from the sky; or the
    whole panel lights yellow and everything that isn&rsquo;t the mark winks off.</p>
    __SWARM__
    __DRIP__
    __WINK__
  </section>

  <p class="pair-label">Everything &middot; shuffle</p>
  <section>
    <h2>The 24/7 mode</h2>
    <p class="desc">Acts strictly alternate: an abstract logo act &mdash; build, dwell
    treatment, exit, all family-scheduled so nothing similar plays twice running,
    with the layout rotating the same way &mdash; then a shop activity (strike, laser,
    weld, print, saw, wheel, stitch&hellip;), then abstract again. The activities draw
    from their own weighted deck, so the same tool never works two turns in a row.
    ~14% of abstract turns are the ignition or molten specials. The first act after
    power-up is always the strike.</p>
    __SHUFFLE__
  </section>

  <section>
    <h2>Run it</h2>
    <pre><span class="c"># opens the pygame simulator window</span>
cd ~/Documents/Projects/theforge-led-logo
python3 forge_logo.py strike|laser|sawmill|print|weld|wheel|stitch \\
                      block|rows|emblem|badge|heat|molten|temper|shuffle

<span class="c"># regenerate these previews headlessly</span>
python3 preview.py

<span class="c"># ship to a USB-mounted MatrixPortal S3</span>
scripts/deploy.sh --dry-run</pre>
  </section>

  <section>
    <h2>Notes</h2>
    <ul>
      <li><strong>Brand-true by construction.</strong> Yellow sampled from the logo
      asset (#F7EE21); the knockout block is the actual brand lockup, free on an LED
      panel (unlit pixels are the letterforms). The one design rule: recognizably
      yellow-on-black at all times, heat tones only, cool colors strictly diegetic
      (laser red, arc blue-white), no strobes.</li>
      <li><strong>Hardware-safe.</strong> Everything is prebuilt TileGrids + palette
      writes; the spark pool is ten 1-LED tiles on precomputed ballistic arcs sharing
      one 3-color palette; the laser cut and printer are palette sweeps over
      pre-banded partitions. Same 50ms/20fps budget the DarkOwl sign ships on.</li>
      <li><strong>Iterate.</strong> Pixel art is ASCII rows in <code>glyphs.py</code>
      (letters at three sizes, both anvils, hammer poses, all the tools); layouts and
      scene timing live at the top of <code>forge_logo.py</code>.</li>
    </ul>
  </section>
</main>
"""


REPLACEMENTS = {
    "__STATIC__": fig("static.png", "FORGE wordmark in safety yellow on a 64x32 LED matrix, ember pilot light in the O", "static &middot; 64&times;32 &middot; CAPS20", "hold + pilot flare", first=True),
    "__LINE__": fig("line.gif", "The FORGE line layout wipes in, heat rings out from the O, wipes away", "line &middot; strikewake from the O", "python3 forge_logo.py line", first=True),
    "__BLOCK__": fig("block.gif", "The knockout block layout: lit yellow rectangle with unlit FORGE letterforms", "block &middot; heat haze on the field", "the brand mark, literally"),
    "__ROWS__": fig("rows.gif", "THE over FORGE two-row layout with falling ember phases", "rows &middot; sparkrain", "THE at 5x8, FORGE at 10x20"),
    "__EMBLEM__": fig("emblem.gif", "FORGE standing over the stencil anvil, heat blooming from the anvil face", "emblem &middot; heatbloom from the anvil", "the strike builds this one"),
    "__BADGE__": fig("badge.gif", "Big stencil anvil left, THE FORGE stacked right, heat wake", "badge &middot; wake from the big anvil", "python3 forge_logo.py badge"),
    "__STRIKE__": fig("strike.gif", "A steel anvil drops in and a hammer forges the FORGE letters white-hot with spark showers", "strike &middot; ~13s loop", "the boot opener", first=True),
    "__UNFORGE__": fig("unforge.gif", "The hammer knocks the letters out in spark bursts and the anvil reverts to steel", "unforge &middot; exit twin", "same spark pool, reversed story"),
    "__LASER__": fig("laser.gif", "A red laser beam cuts the FORGE letterforms out of a gray steel plate with rising sparks", "laser &middot; ~11s loop", "beam + spark plume + palette-sweep cut", first=True),
    "__SAWMILL__": fig("sawmill.gif", "A circular saw rips a board that feeds through, kerf opening, sawdust flying", "sawmill &middot; interstitial", "2-pose blade spin", first=True),
    "__SAWCUT__": fig("sawcut.gif", "The saw crosses the FORGE mark cutting it in half; the halves fall apart", "sawcut &middot; exit", "prebuilt half bitmaps + kerf line"),
    "__PRINT__": fig("print.gif", "A printer nozzle rasters the FORGE mark bottom-up, fresh layers glowing orange", "print &middot; ~10s loop", "row partition, 1 paint per band", first=True),
    "__WELD__": fig("weld.gif", "A MIG torch travels the block's perimeter laying a cooling bead, then the interior floods yellow", "weld &middot; ~10s loop", "blue-white arc, diegetic only", first=True),
    "__QUENCH__": fig("quench.gif", "The mark heats through the ramp and drops off the bottom edge with pale spray", "quench &middot; exit", "heat + fall + steam"),
    "__WHEEL__": fig("wheel.gif", "A potter's wheel spins while clay morphs from lump to pot, then fires kiln-hot", "wheel &middot; interstitial", "4 clay profiles + kiln flash", first=True),
    "__STITCH__": fig("stitch.gif", "A sewing machine crosses under FORGE leaving a dashed stitch rule", "stitch &middot; accent", "11 dash tiles behind the needle"),
    "__HEAT__": fig("heat.gif", "The FORGE mark glows up through a red-to-white heat gradient and breathes", "heat &middot; ignition special", "5-stop black-body ramp", first=True),
    "__MOLTEN__": fig("molten.gif", "Banded molten light sweeps behind the mark's strokes on a black panel", "molten &middot; aperture special", "64x64 backdrop behind a hole mask"),
    "__TEMPER__": fig("temper.gif", "The mark cycles through steel-temper color editions", "temper &middot; six editions", "the nocturne of this sign"),
    "__ANNEAL__": fig("anneal.gif", "A hot sheen sweeps diagonally across the yellow mark", "anneal &middot; diagonal sweep", "10 bands", first=True),
    "__STRIKEWAKE__": fig("strikewake.gif", "Heat rings flow outward from the O through the letters", "strikewake &middot; anchored wake", "10 distance bands"),
    "__CASEHARDEN__": fig("caseharden.gif", "Stroke edges cool dark while cores glow", "caseharden &middot; topology", "how steel actually cools"),
    "__TOOLPATH__": fig("toolpath.gif", "Hot packets crawl the letterform strokes and converge on the O", "toolpath &middot; route order", "19 route groups"),
    "__WORKLIGHT__": fig("worklight.gif", "A light source passes over the mark, stroke edges catching highlights", "worklight &middot; exposure", "shop light on the sign"),
    "__SHIMMER__": fig("shimmer.gif", "Interleaved pixels shimmer between two close yellows like heat haze", "shimmer &middot; checker", "the quietest treatment"),
    "__SWARM__": fig("swarm.mp4", "", "swarm + unswarm &middot; ~27s cycle", "16 spark-yellow boids", first=True),
    "__DRIP__": fig("drip.gif", "The mark's pixels rain in from the top and settle", "drip &middot; ~6s loop", "also available bottom-up"),
    "__WINK__": fig("wink.gif", "A full yellow panel winks off pixel by pixel leaving the mark", "wink &middot; ~5s loop", "reveal splash + CRT collapse"),
    "__SHUFFLE__": fig("shuffle.mp4", "", "shuffle &middot; 40s sample", "the 24/7 mode", first=True),
}


def main():
    html = HTML
    for key, value in REPLACEMENTS.items():
        html = html.replace(key, value)
    OUT.write_text(html)
    print("wrote", OUT, len(html) // 1024, "KB")


if __name__ == "__main__":
    main()
