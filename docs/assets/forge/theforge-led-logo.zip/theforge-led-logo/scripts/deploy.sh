#!/usr/bin/env bash
# Deploy The Forge LED logo to a USB-connected MatrixPortal S3 (CIRCUITPY).
#
# On-device layout:
#   /code.py                       entry point (runs the shuffle)
#   /forge_logo.py /glyphs.py      the app, at the drive root
#   /lib/scrollkit/**              the ScrollKit library (excl simulator/ dev/)
#   /lib/asyncio/** /lib/adafruit_ticks.mpy       bundle deps for the run loop
#
# Modeled on darkowl-led-logo/scripts/deploy.sh (itself modeled on the
# themeparkwaits S3 deploy). The Adafruit bundle libs are auto-picked to
# match the board's CircuitPython major version, read from boot_out.txt.
#
# Usage:
#   scripts/deploy.sh --dry-run     # show what would copy, touch nothing
#   scripts/deploy.sh               # deploy for real
#
# Env:
#   CIRCUITPY       mount point (default: /Volumes/CIRCUITPY)
#   SCROLLKIT_SRC   scrollkit package dir
#                   (default: ~/Documents/Projects/ScrollKit/ScrollKit Library/src/scrollkit)
#   BUNDLE_DIR      Adafruit bundle lib dir (default: newest matching bundle
#                   under ~/Documents/Projects/ScrollKit/)
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${CIRCUITPY:-/Volumes/CIRCUITPY}"
LIB_SRC="${SCROLLKIT_SRC:-$HOME/Documents/Projects/ScrollKit/ScrollKit Library/src/scrollkit}"
BUNDLES_HOME="$HOME/Documents/Projects/ScrollKit"

DRY=0
[ "${1:-}" = "--dry-run" ] && DRY=1

[ -d "$DEST" ] || { echo "deploy: CIRCUITPY not mounted at '$DEST' — plug in the board." >&2; exit 1; }
[ -f "$DEST/boot_out.txt" ] || echo "deploy: warning — '$DEST' has no boot_out.txt; is it really CIRCUITPY?" >&2
[ -d "$LIB_SRC" ] || { echo "deploy: scrollkit not found at '$LIB_SRC' (set SCROLLKIT_SRC)." >&2; exit 1; }

# Pick the bundle matching the board's CircuitPython major version.
if [ -z "${BUNDLE_DIR:-}" ]; then
  CP_MAJOR="$(sed -n 's/^Adafruit CircuitPython \([0-9]*\)\..*/\1/p' "$DEST/boot_out.txt" 2>/dev/null | head -1)"
  [ -n "$CP_MAJOR" ] || { echo "deploy: cannot read CircuitPython version from boot_out.txt (set BUNDLE_DIR)." >&2; exit 1; }
  BUNDLE_DIR="$(ls -d "$BUNDLES_HOME"/adafruit-circuitpython-bundle-"$CP_MAJOR".x-mpy-* 2>/dev/null | sort | tail -1)/lib"
fi
[ -d "$BUNDLE_DIR" ] || { echo "deploy: bundle libs not found at '$BUNDLE_DIR' (set BUNDLE_DIR)." >&2; exit 1; }
echo "==> CircuitPython $(sed -n 's/^Adafruit CircuitPython \([^ ]*\).*/\1/p' "$DEST/boot_out.txt" | head -1); bundle: $BUNDLE_DIR"

RSYNC_OPTS=(-rt --no-perms --no-owner --no-group --modify-window=2
            --exclude=__pycache__ --exclude='*.pyc' --exclude='.DS_Store' --exclude='._*')
[ "$DRY" = 1 ] && RSYNC_OPTS+=(-n -v) && echo "== DRY RUN — nothing will be written =="

echo "==> app: code.py + forge_logo.py + glyphs.py  ->  $DEST"
rsync "${RSYNC_OPTS[@]}" "$REPO_ROOT/code.py" "$REPO_ROOT/forge_logo.py" \
      "$REPO_ROOT/glyphs.py" "$DEST/"

# scrollkit/simulator (pygame) and scrollkit/dev are desktop-only; exclude and
# prune (--delete-excluded, else rsync protects them from --delete).
echo "==> library: scrollkit  ->  $DEST/lib/scrollkit  (excl simulator/ + dev/)"
[ "$DRY" = 0 ] && mkdir -p "$DEST/lib/scrollkit"
rsync "${RSYNC_OPTS[@]}" --delete --delete-excluded --exclude=/simulator --exclude=/dev \
      "$LIB_SRC/" "$DEST/lib/scrollkit/"

# The non-network bundle set scrollkit's display path needs on-device
# (the same set the darkowl and themeparkwaits boxes run): the async run
# loop, the display-text stack, and the MatrixPortal panel constructor +
# its deps.
BUNDLE_LIBS=(asyncio adafruit_ticks.mpy
             adafruit_display_text adafruit_bitmap_font
             adafruit_matrixportal adafruit_portalbase
             adafruit_bus_device adafruit_pixelbuf.mpy neopixel.mpy)
echo "==> bundle deps: ${BUNDLE_LIBS[*]}  ->  $DEST/lib/"
for lib in "${BUNDLE_LIBS[@]}"; do
  rsync "${RSYNC_OPTS[@]}" "$BUNDLE_DIR/$lib" "$DEST/lib/"
done

if [ "$DRY" = 1 ]; then
  echo "== DRY RUN complete — re-run without --dry-run to deploy =="
  exit 0
fi

# Purge the AppleDouble (._*) metadata macOS writes alongside every FAT copy.
JUNK="$(find "$DEST" \( -name '._*' -o -name '.DS_Store' \) -type f | wc -l | tr -d ' ')"
if [ "$JUNK" != "0" ]; then
  echo "==> purging $JUNK macOS metadata file(s)"
  find "$DEST" \( -name '._*' -o -name '.DS_Store' \) -type f -delete
fi
sync
echo "==> done. Let the board reload, then watch boot on the serial console:"
echo "    screen /dev/cu.usbmodem* 115200    (or:  tio /dev/cu.usbmodem*)"
