#!/usr/bin/env python3
"""Render every glyph and sprite big (LED-dot style) for art iteration.

    python3 sprite_check.py     ->  previews/sprites.png

Each entry in GROUPS is one output row: a list of sprites drawn side by
side (so whole words can be judged as words).
"""

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import importlib

import glyphs

importlib.reload(glyphs)

from PIL import Image, ImageDraw  # noqa: E402

DOT = 10  # pixels per LED
GAP = 8   # gap between sprite groups
SP = 2    # LED columns between sprites within a group

_ALL_COLORS = glyphs.PALETTE_COLORS + glyphs.HEAT_RAMP + glyphs.MATERIAL_SHADES
SLOT_RGB = {0: None}
for _slot in set(glyphs.CHAR_TO_SLOT.values()):
    if _slot:
        _c = _ALL_COLORS[_slot]
        SLOT_RGB[_slot] = tuple((_c >> s) & 0xFF for s in (16, 8, 0))


def draw_sprite(draw, rows, ox, oy):
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            rgb = SLOT_RGB[glyphs.CHAR_TO_SLOT[ch]]
            cx, cy = ox + x * DOT, oy + y * DOT
            draw.ellipse([cx + 1, cy + 1, cx + DOT - 3, cy + DOT - 3],
                         fill=rgb or (14, 14, 14))


def main():
    caps20 = [glyphs.CAPS20[c] for c in "FRGE"]
    caps20.insert(1, glyphs.O_CORE20)
    caps13 = [glyphs.CAPS13[c] for c in "FRGE"]
    caps13.insert(1, glyphs.O_CORE13)
    caps8_the = [glyphs.CAPS8[c] for c in "THE"]
    caps8_forge = [glyphs.CAPS8[c] for c in "FORGE"]
    GROUPS = [
        caps20,
        caps13,
        caps8_the + caps8_forge,
        [glyphs.knockout_rows("FORGE", glyphs.CAPS13, 4, 2, 2,
                              core=glyphs.O_CORE13)],
        [glyphs.ANVIL, glyphs.ANVIL_LOGO],
        [glyphs.HAMMER_UP, glyphs.HAMMER_MID, glyphs.HAMMER_DOWN],
        [glyphs.SPARK_BURST_A, glyphs.SPARK_BURST_B, glyphs.SPARK_BURST_C],
    ]
    for group in GROUPS:
        for rows in group:
            widths = {len(r) for r in rows}
            assert len(widths) == 1, "ragged sprite rows: %s" % sorted(widths)

    group_w = [sum(len(r[0]) + SP for r in g) * DOT for g in GROUPS]
    group_h = [max(len(r) for r in g) * DOT for g in GROUPS]
    w = max(group_w) + 2 * GAP
    h = sum(group_h) + GAP * (len(GROUPS) + 1)
    img = Image.new("RGB", (w, h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    oy = GAP
    for g, gh in zip(GROUPS, group_h):
        ox = GAP
        for rows in g:
            draw_sprite(draw, rows, ox, oy)
            ox += (len(rows[0]) + SP) * DOT
        oy += gh + GAP
    out = os.path.join(_HERE, "previews", "sprites.png")
    img.save(out)
    print("wrote", out)


if __name__ == "__main__":
    main()
