# The Forge LED Logo

The [Forge Greensboro](https://www.forgegreensboro.org) wordmark and a
cast of maker vignettes, animated for a 64x32 RGB LED matrix (Adafruit
MatrixPortal S3, [ScrollKit](https://scrollkit.dev)). Safety-yellow FORGE
in five layouts — including the brand's knockout yellow block — built,
dwelled on, and dismantled by the shops themselves: a blacksmith's hammer
forges the letters white-hot, the laser cutter cuts them out of steel
plate, the table saw reveals them behind a ripped board, the 3D printer
rasters them layer by layer.

Runs unchanged in ScrollKit's desktop simulator:

```
python3 forge_logo.py static      # the mark, held (pilot-light breathe)
python3 forge_logo.py strike      # hammer + anvil forge the wordmark
python3 forge_logo.py laser       # the laser cuts the knockout block
python3 forge_logo.py shuffle     # the 24/7 mode: everything, scheduled
python3 preview.py                # headless renders -> previews/
```

Deploy to a USB-mounted board with `scripts/deploy.sh`.

See `CLAUDE.md` for architecture, constraints, and the design rules.
